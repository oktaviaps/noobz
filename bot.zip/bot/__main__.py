from bot import *
from importlib import import_module
from bot.modules import ALL_MODULES
for module_name in ALL_MODULES:
	try:
		imported_module = import_module("bot.modules." + module_name)
	except:
		print("anjg")
		print(module_name)
		imported_module = import_module("bot.modules." + module_name + ".web")
	print("IMPORTED: "+str(imported_module) )
if __name__ == "__main__":
	bot.loop.run_until_complete(sbot())


