from bot import *

@bot.on(events.CallbackQuery(data=b'manage'))
async def manage(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	val = valid(sender.id)
	total = domains()
	ser = namas()
	harga = hargas()
	lists = []
	
	for i,k in zip(ser[0], harga[0]) :
		print(i)
		print(k)
		nname = i[0]
		price = k[1]
		lists.append(f"**» {name}:** `Rp. {price}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Create Account Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» 🖥Total Server:** `{total}`
{"".join(lists)}


**━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[


[Button.inline(" Create Vmess ","vmess"),
Button.inline(" Trial Vmess ","vmess-trial")],
[Button.inline(" Create Trojan ","trojan"),
Button.inline("Trial Trojan ","trojan-trial")],
[Button.inline(" Back To Menu","menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Create Account Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» 🖥Total Server:** `{total}`
**» 💵Saldo Kamu:** `{val["saldo"]}`
**» 🤖@XolPanel**
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg, buttons=[
[Button.inline(" Create Vmess ","vmess"),
Button.inline(" Trial Vmess ","vmess-trial")],
[Button.inline(" Create Trojan ","trojan"),
Button.inline(" Trial Trojan ","trojan-trial")],
[Button.inline(" Back To Menu","menu")]])

