from bot import *

@client.on(events.CallbackQuery(data=b'menu'))
@client.on(events.NewMessage(pattern="(?: /menu|.menu)$"))
async def menu(event):
	sender = await event.get_sender()
	await event.respond("Hello!")
