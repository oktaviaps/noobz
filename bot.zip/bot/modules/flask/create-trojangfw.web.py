from bot import *

@app.route("/create-trojangfw", methods=["GET","POST"])
async def trojangfwCreate():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			xjs = eval(x)
			servers = []
			db = get_db()
			lim = db.execute("SELECT limcounted FROM trojangfw").fetchall()
			cont = db.execute("SELECT counted FROM trojangfw").fetchall()
			domain = db.execute("SELECT domain FROM trojangfw").fetchall()
			name = db.execute("SELECT buttonname FROM trojangfw").fetchall()
			harga = db.execute("SELECT harga FROM trojangfw").fetchall()
			print(harga)
			a = 0
			for i, j, v, z, l in zip(domain, name, harga, cont, lim):
				hargaa = "{:,}".format(harga[a][0])
				servers.append({"host":f"{domain[a][0]},{harga[a][0]},{name[a][0]}","name":f"{name[a][0]} - Rp. {hargaa} - Slot {cont[a][0]}/{lim[a][0]} - Quota {quota[a][0]}GB", "price":harga[a][0]})
				a += 1
#			z = db.execute("SELECT buttonname FROM trojangfw").fetchall()
			print(servers)
			return render_template("create-trojangfw.html",servers=servers)
		else:
			return redirect("/login")
	elif request.method == "POST":
		x = request.cookies.get("auth")
		if x:
			db = get_db()
			xjs = eval(x)
			email = xjs["email"]

			telegram = xjs["telegram"]
			saldo = db.execute("SELECT saldo FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			if int(saldo) <= 0:
				flash(Markup("<strong>Create Error!</strong><br>0 Balance, Can't Create Account"))
				return redirect("/create-trojangfw")
			else:
				user = request.form["username"]
				serverv = request.form.get("server").split(",")
				exp = request.form.get("exp").split(",")
				buttonname = serverv[2]
				domain = serverv[0]
				lim = db.execute("SELECT limcounted FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				cont = db.execute("SELECT counted FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				salkur = int(serverv[1]) * int(exp[0])
				user = request.form["user"]
				serverv = request.form.get("server").split(",")
				exp = request.form.get("exp").split(",")
				saldo = db.execute("SELECT saldo FROM userz WHERE email = %s", (email,)).fetchone()[0]
				salkur = int(serverv[1]) * int(exp[0])
				if int(saldo) < int(salkur):
					flash(Markup(f"<strong>Create Error!</strong><br>Not Enough Balance<br>Current Balance: {saldo}$"))
					return redirect("/create-trojan")
				elif not user:
					flash(Markup("<strong>Create Error!</strong><br>Invalid Username"))
					return redirect("/create-trojan")
				else:
					res = requests.get("http://"+serverv+f":6969/trojan-create?user={user}&exp={exp[1]}")
					if res.text != "error":
						print(res.text)
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",
(int(saldo)-int(salkur),telegram,))
						x = db.execute("SELECT saldo, member, email, created FROM user WHERE member = (?)",(telegram,)).fetchone()
						db.execute("UPDATE user SET created = ? WHERE member = ?",
(int(x[3])+int(1),telegram,))

						count = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",
(buttonname,)).fetchone()[0]

						db.execute("UPDATE vmess SET counted = (?) WHERE domain = (?)",
(int(count)+int(1),domain,))
						db.commit()
						x = res.text
						domain = re.search("@(.*?):",x).group(1)
						port = re.search(domain+":(.*)",x).group(1)
						uuid = re.search("trojan://(.*?)@",x).group(1)
						try:
							remarks = re.search("#(.*)",x).group(1)
						except:
							remarks = uuid
						today = DT.date.today()
						later = today + DT.timedelta(days=1)
						exp = later.strftime("%Y-%m-%d")
						exp = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(exp),"%Y-%m-%d"))
						date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
						db.execute("INSERT INTO transaksi (protocol,descr,usd,date,email) VALUES (%s,%s,%s,%s,%s)", (f"{serverv[0]} Trojan","Trojan Account","-"+str(salkur),date,email))
						msg = f"""Premium Trojan GFW Account
Domain: {serverv}<br>
User: {user}<br>
Expiration: {exp}<br>
<hr><br>
Trojan GFW Link:<br>
{x.replace(" ","").strip()}
<hr>
"""
#						await Notif("Premium","Trojan",exp,email,salkur,server[0])
						return render_template("create-trojangfw.html",result=msg)
					else:
						flash(Markup("<strong>Create Error</strong> User Already Exist"))
						return redirect("/create-trojan")




