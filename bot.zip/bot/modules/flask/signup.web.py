from bot import *

@app.route("/signup", methods=["GET","POST"])
async def signup():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			return render_template("signup.html")
	else:
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			email = request.form["email"]
			telegram = request.form["telegram"]
			password = request.form["password"]
			exist = [l[0] for l in db.execute("SELECT email FROM userz").fetchall()]
			if email in exist:
				flash(Markup("<strong>Register Error!</strong><br>Email Already Exist"))
				return redirect("/signup")
			else:
				db.execute("INSERT INTO userz (email,telegram,password) VALUES (%s,%s,%s)", (email,telegram,password,))
				db.execute("UPDATE userz SET saldo = %s WHERE email = %s",("0",email))
				flash(Markup("<strong>Register Success!</strong><br>Please <a href='/login'>Log-in</a>"))
				return redirect("/signup")
