from bot import *

@app.route("/login", methods=["GET","POST"])
async def login():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			return redirect("/connect")
	else:
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			return redirect("/connect")
"""
			email = request.form["email"]
			password = request.form["password"]
			exist = [l[0] for l in db.execute("SELECT email FROM userz").fetchall()]
			if email not in exist:
				flash(Markup("<strong>Login Error!</strong><br>Email Does not Exist"))
				return redirect("/login")
			else:
				pw = db.execute("SELECT password FROM userz WHERE email = %s", (email,)).fetchone()[0]
				if pw == password:
					res = make_response(redirect("/"))
					xc = {"email":email,"password":password}
					res.set_cookie("auth",str(xc), expires=datetime.datetime.now() + datetime.timedelta(days=30))
					return res
				else:
					flash(Markup("<strong>Login Error!</strong><br>Incorrect Password"))
					return redirect("/login")
"""
