from bot import *

@app.route("/profile", methods=["GET","POST"])
async def profile():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if not x:
			return redirect("/")
		else:
			xjs = eval(x)
			return render_template("profile.html", email=xjs["email"])
	else:
		x = request.cookies.get("auth")
		if not x:
			return redirect("/")
		else:
			xjs = eval(x)
			password = request.form["password"]
			password_new = request.form["password-new"]
			if password == xjs["password"]:
				db.execute("UPDATE userz SET password = %s WHERE email = %s", (password_new, xjs['email'],))
				s = "Password updated. please log-in"
				resp = make_response( render_template("profile.html",result=s) )
				resp.set_cookie("SessionID","", expires=0)
				return resp
			else:
				flash("Error: Password mismatch")
				return redirect("/profile")

