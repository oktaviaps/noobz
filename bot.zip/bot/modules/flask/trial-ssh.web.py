from bot import *

@app.route("/trial-ssh", methods=["GET","POST"])
async def trialSSH():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			servers = []
			db = get_db()
			lim = db.execute("SELECT limcounted FROM ssh").fetchall()
			cont = db.execute("SELECT counted FROM ssh").fetchall()
			domain = db.execute("SELECT domain FROM ssh").fetchall()
			name = db.execute("SELECT buttonname FROM ssh").fetchall()
			harga = db.execute("SELECT harga FROM ssh").fetchall()
			a = 0
			for i, j, v, z, l in zip(domain, name, harga, cont, lim):
				hargaa = "{:,}".format(harga[a][0])
				servers.append({"host":f"{domain[a][0]},{harga[a][0]},{name[a][0]}","name":f"{name[a][0]} - Rp. {hargaa} - Slot {cont[a][0]}/{lim[a][0]}", "price":harga[a][0]})
				a += 1
			xjs = eval(x)
			return render_template("trial-ssh.html",servers=servers, title="trial SSH")
		else:
			return redirect("/")
	else:
		x = request.cookies.get("auth")
		if not x:
			return redirect("/")
		else:
			db = get_db()
			xjs = eval(x)
			telegram = xjs["telegram"]
			saldo = db.execute("SELECT saldo FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			user = request.form["username"]
			pw = request.form["password"]
			server = request.form.get("server").split(",")
			exp = 1
			buttonname = server[2]
			domain = server[0]
			portwsntls = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			portwstls = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			portdb = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			lim = db.execute("SELECT limcounted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			cont = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			cont = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
#				saldo = db.execute("SELECT saldo FROM userz WHERE user = %s", (telegram,)).fetchone()[0]
			if not user:
				flash(Markup("<strong>trial Error!</strong><br>Invalid Username"))
				return redirect("/trial-ssh")
			elif not pw:
				flash(Markup("<strong>trial Error!</strong><br>Invalid Password"))
				return redirect("/trial-ssh")
			elif len(user) < 7:
				flash(Markup("<strong>trial Error!</strong><br>Username Must Be Atleast 7 Characters"))
				return redirect("/trial-ssh")
			else:
				r = requests.get("http://"+server[0]+f":6969/adduser/exp?user={user}&password={pw}&exp={exp}&limitip={limitip}")
				if r.text == "success":
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					expz = later.strftime("%Y-%m-%d")
					expd = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(expz),"%Y-%m-%d"))
					date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
					s = Markup(f"""<strong>Trial SSH Account<br>
<hr><br>
Hostname: {server[0]}<br>
Username: {user}<br>
Password: {pw}<br>
Expiry: {expd}<br>
<hr><br>
Port Info:<br>
Websocket SSL: {portwstls}<br>
Websocket HTTP: {portwsntls}<br>
Dropbear: {portdb}<br>
OpenSSH: 22<br>
SSL/TLS: 443, 777<br>
<hr><br>
Websocket Payload:<br>
GET / HTTP/1.1[crlf]Host: {server[0]}[crlf]Connection: Upgrade[crlf][crlf]</strong>""")
#					await Notif("Premium","SSH",expd,email,salkur,server[0])
					return render_template("trial-ssh.html",result=s)
				else:
					flash(Markup(f"<strong>trial Error!</strong><br>Username Already Exist"))
					return redirect("/trial-ssh")
