from bot import *

@app.route("/", methods=["GET","POST"])
async def home():
	x = request.cookies.get("auth")
	if x:
		db = get_db()
		xjs = eval(x)
		print(xjs)
		telegram = xjs["telegram"]
#		telegram = db.execute("SELECT member FROM userz WHERE member = ?", (xjs["telegram"],)).fetchone()[0]
		saldo = db.execute("SELECT saldo FROM user WHERE member = ?", (xjs["telegram"],)).fetchone()[0]
		saldo = "{:,}".format(saldo)
		alltrans = db.execute("SELECT created FROM user WHERE member = ?",(xjs["telegram"],)).fetchone()[0]
		return render_template("index.html", balance=saldo, total_servers=str(len(servers)), telegram=telegram, translist=alltrans )
	else:
		return redirect("/login")
