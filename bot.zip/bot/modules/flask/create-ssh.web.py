from bot import *

@app.route("/create-ssh", methods=["GET","POST"])
async def createSSH():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			servers = []
			db = get_db()
			lim = db.execute("SELECT limcounted FROM ssh").fetchall()
			cont = db.execute("SELECT counted FROM ssh").fetchall()
			domain = db.execute("SELECT domain FROM ssh").fetchall()
			name = db.execute("SELECT buttonname FROM ssh").fetchall()
			harga = db.execute("SELECT harga FROM ssh").fetchall()
			a = 0
			for i, j, v, z, l in zip(domain, name, harga, cont, lim):
				hargaa = "{:,}".format(harga[a][0])
				servers.append({"host":f"{domain[a][0]},{harga[a][0]},{name[a][0]}","name":f"{name[a][0]} - Rp. {hargaa} - Slot {cont[a][0]}/{lim[a][0]}", "price":harga[a][0]})
				a += 1
			xjs = eval(x)
			return render_template("create-ssh.html",servers=servers, title="Create SSH")
		else:
			return redirect("/")
	else:
		x = request.cookies.get("auth")
		if not x:
			return redirect("/")
		else:
			db = get_db()
			xjs = eval(x)
			telegram = xjs["telegram"]
			saldo = db.execute("SELECT saldo FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			user = request.form["username"]
			pw = request.form["password"]
			server = request.form.get("server").split(",")
			exp = request.form.get("exp").split(",")
			buttonname = server[2]
			domain = server[0]
			portwsntls = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			portwstls = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			pubkey = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			portdb = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			lim = db.execute("SELECT limcounted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			cont = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
			cont = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
#				saldo = db.execute("SELECT saldo FROM userz WHERE user = %s", (telegram,)).fetchone()[0]
			salkur = int(server[1]) * int(exp[0])
			if int(saldo) < int(salkur):
				flash(Markup(f"<strong>Create Error!</strong><br>Not Enough Balance<br>Current Balance: {saldo}$"))
				return redirect("/create-ssh")
			elif not user:
				flash(Markup("<strong>Create Error!</strong><br>Invalid Username"))
				return redirect("/create-ssh")
			elif not pw:
				flash(Markup("<strong>Create Error!</strong><br>Invalid Password"))
				return redirect("/create-ssh")
			elif len(user) < 7:
				flash(Markup("<strong>Create Error!</strong><br>Username Must Be Atleast 7 Characters"))
				return redirect("/create-ssh")
			elif lim == cont:
				flash(Markup("<strong>Create Error!</strong><br>Server Full"))
				return redirect("/create-ssh")
			else:
				r = requests.get("http://"+server[0]+f":6969/adduser/exp?user={user}&password={pw}&exp={exp[1]}&limitip={limitip}")
				if r.text == "success":
					x = db.execute("SELECT saldo, member, email, created FROM user WHERE member = (?)",(telegram,)).fetchone()
					db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(saldo)-int(salkur),telegram,))
					db.execute("UPDATE user SET created = ? WHERE member = ?",(int(x[3])+int(1),telegram,))
					count = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					db.execute("UPDATE ssh SET counted = (?) WHERE domain = (?)",
					(int(count)+int(1),domain,))
					db.commit()
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp[1]))
					expz = later.strftime("%Y-%m-%d")
					expd = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(expz),"%Y-%m-%d"))
					date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
					s = Markup(f"""<strong>Premium SSH Account<br>
<hr><br>
Hostname: {server[0]}<br>
Username: {user}<br>
Password: {pw}<br>
PubKey: {pubkey}<br>
Expiry: {expd}<br>
<hr><br>
Port Info:<br>
Websocket SSL: {portwstls}<br>
Websocket HTTP: {portwsntls}<br>
Dropbear: {portdb}<br>
OpenSSH: 22<br>
SSL/TLS: 443, 777<br>
<hr><br>
Websocket Payload:<br>
GET / HTTP/1.1[crlf]Host: {server[0]}[crlf]Connection: Upgrade[crlf][crlf]</strong>""")
#					await Notif("Premium","SSH",expd,email,salkur,server[0])
					return render_template("create-ssh.html",result=s)
				else:
					flash(Markup(f"<strong>Create Error!</strong><br>Username Already Exist"))
					return redirect("/create-ssh")
