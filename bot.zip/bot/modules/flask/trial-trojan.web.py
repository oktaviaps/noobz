from bot import *

@app.route("/trial-trojan", methods=["GET","POST"])
async def trojanTrialz():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			xjs = eval(x)
			return render_template("trial-trojan.html",servers=servers)
		else:
			return redirect("/login")
	elif request.method == "POST":
		x = request.cookies.get("auth")
		if x:
			xjs = eval(x)
			email = xjs["email"]
			saldo = db.execute("SELECT saldo FROM userz WHERE email = %s",(xjs["email"],)).fetchone()[0]
			if int(saldo) <= 0:
				flash(Markup("<strong>Trial Error!</strong><br>0 Balance, Can't Create Trial"))
				return redirect("/trial-trojan")
			else:
				user = request.form["user"]
				serverv = request.form.get("server")
				if not user:
					flash(Markup("<strong>Trial Error!</strong><br>Invalid Username"))
					return redirect("/trial-trojan")
				else:
					res = requests.get("http://"+serverv+f":6969/create-trgo?user={user}&exp=1")
					if res.text != "error":
						print(res.text)
						x = eval(res.text)
						today = DT.date.today()
						later = today + DT.timedelta(days=1)
						exp = later.strftime("%Y-%m-%d")
						exp = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(exp),"%Y-%m-%d"))
						date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
						db.execute("INSERT INTO transaksi (protocol,descr,usd,date,email) VALUES (%s,%s,%s,%s,%s)", (f"{serverv} Trojan","Trial Trojan Account","0",date,email))
						msg = f"""Domain: {serverv}<br>
User: {user}<br>
Expiration: {exp}<br>
<hr><br>
Trojan GFW Link:<br>
{x[0]}
<hr><br>
Trojan GO / WS Link:<br>
{x[1]}
"""
						await Notif("Trial","Trojan",exp,email,salkur,server)
						return render_template("trial-trojan.html",result=msg)
					else:
						flash(Markup("<strong>Trial Error</strong> User Already Exist"))
						return redirect("/trial-trojan")
