from bot import *

@app.route("/topup", methods=["GET","POST"])
async def topup():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			return render_template("topup.html")
		else:
			return redirect("/")
	else:
		x = request.cookies.get("auth")
		if not x:
			return redirect("/")
		else:
			db = get_db()
			telegram = eval(x)["telegram"]
#			name = db.execute("SELECT email FROM userz WHERE email = %s",(email,))
			email = db.execute("SELECT email FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			amount = request.form["amount"]
			signStr = "{}{}{}".format(merchant_code, merchant_ref, amount)
			signature = hmac.new(bytes(privateKey,'latin-1'), bytes(signStr,'latin-1'), hashlib.sha256).hexdigest()
			url = "https://tripay.co.id/api/transaction/create"
			head = {"Authorization":"Bearer DEV-ru6vJMN2o0xr0U4upAgxRJX9TyCHE5xB5Z653LHo"}
			data = {
	"method":"QRIS2",
        "amount":amount,
        "merchant_ref": merchant_ref,
        "customer_name":email,
        "customer_email":email,
        "return_url":"http://lisens.red-flat.my.id/",
	"expired_time":expiry,
	"signature":signature
	}

			order_items = [
    {
      'sku': 'TopUp',
      'name': f'TopUp Saldo Nominal {amount}',
      'price': amount,
      'quantity': 1,
      'product_url': 'https://lisens.red-flat.my.id/',
      'image_url': 'null'
    }
  ]
			i = 0
			for item in order_items:
			        for k in item:
			                data['order_items['+ str(i) +']['+ str(k) +']'] = item[k]
			        i += 1
			result = requests.post(url="https://tripay.co.id/api-sandbox/transaction/create", data=data, headers=head)
			response = result.text
			js = json.loads(response)
			if result.status_code == 200:
				return render_template("topup.html", link=js["data"]["checkout_url"])
			else:
				return response
