from bot import *

@app.route("/create-trojango", methods=["GET","POST"])
async def trojangoCreate():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			xjs = eval(x)
			servers = []
			db = get_db()
			lim = db.execute("SELECT limcounted FROM trojango").fetchall()
			cont = db.execute("SELECT counted FROM trojango").fetchall()
			domain = db.execute("SELECT domain FROM trojango").fetchall()
			name = db.execute("SELECT buttonname FROM trojango").fetchall()
			harga = db.execute("SELECT harga FROM trojango").fetchall()
			print(harga)
			a = 0
			for i, j, v, z, l in zip(domain, name, harga, cont, lim):
				hargaa = "{:,}".format(harga[a][0])
				servers.append({"host":f"{domain[a][0]},{harga[a][0]},{name[a][0]}","name":f"{name[a][0]} - Rp. {hargaa} - Slot {cont[a][0]}/{lim[a][0]}", "price":harga[a][0]})
				a += 1
#			z = db.execute("SELECT buttonname FROM trojango").fetchall()
			print(servers)
			return render_template("create-trojango.html",servers=servers)
		else:
			return redirect("/login")
	elif request.method == "POST":
		x = request.cookies.get("auth")
		if x:
			db = get_db()
			xjs = eval(x)
			telegram = xjs["telegram"]
			saldo = db.execute("SELECT saldo FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			if int(saldo) <= 0:
				flash(Markup("<strong>Create Error!</strong><br>0 Balance, Can't Create Account"))
				return redirect("/create-trojango")
			else:
				db = get_db()
				user = request.form["username"]
				serverv = request.form.get("server").split(",")
				exp = request.form.get("exp").split(",")
				buttonname = serverv[2]
				domain = serverv[0]
				lim = db.execute("SELECT limcounted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				cont = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				salkur = int(serverv[1]) * int(exp[0])
				serverv = request.form.get("server").split(",")
				exp = request.form.get("exp").split(",")
				salkur = int(serverv[1]) * int(exp[0])
				if int(saldo) < int(salkur):
					flash(Markup(f"<strong>Create Error!</strong><br>Not Enough Balance<br>Current Balance: {saldo}$"))
					return redirect("/create-trojango")
				elif not user:
					flash(Markup("<strong>Create Error!</strong><br>Invalid Username"))
					return redirect("/create-trojango")
				elif lim == cont:
					flash(Markup("<strong>Create Error!</strong><br>Server Full"))
					return redirect("/create-trojango")
				else:
					res = requests.get("http://"+serverv[0]+f":6969/create-trgo?user={user}&exp={exp[1]}")
					if res.text != "error":
						print(res.text)
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",
(int(saldo)-int(salkur),telegram,))
						x = db.execute("SELECT saldo, member, email, created FROM user WHERE member = (?)",(telegram,)).fetchone()
						db.execute("UPDATE user SET created = ? WHERE member = ?",
(int(x[3])+int(1),telegram,))

						count = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",
(buttonname,)).fetchone()[0]

						db.execute("UPDATE trojango SET counted = (?) WHERE domain = (?)",
(int(count)+int(1),domain,))
						db.commit()
						x = res.text
						key = re.search("trojan-go://(.*?)@",x).group(1)
						domain = re.search("@(.*?):",x).group(1)
						port = re.search(domain+":(.*?)/",x).group(1)
						remarks = key
						path = re.search("path=(.*?)&",x).group(1)
						try:
							remarks = re.search("#(.*)",x).group(1)
						except:
							remarks = uuid
						today = DT.date.today()
						later = today + DT.timedelta(days=1)
						exp = later.strftime("%Y-%m-%d")
						exp = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(exp),"%Y-%m-%d"))
						date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
						msg = f"""Premium Trojan GO Account<br>
Domain: {serverv[0]}<br>
Remarks: {remarks}<br>
Port: {port}<br>
Key: {key}<br>
Path: {path}<br>
User: {user}<br>
Expiration: {exp}<br>
<hr><br>
Trojan GO Link:<br>
{x.replace(" ","").strip()}
<hr>
"""
#						await Notif("Premium","Trojan",exp,email,salkur,server[0])
						return render_template("create-trojango.html",result=msg)
					else:
						flash(Markup("<strong>Create Error</strong> User Already Exist"))
						return redirect("/create-trojango")
	else:
		return "kontoll"




