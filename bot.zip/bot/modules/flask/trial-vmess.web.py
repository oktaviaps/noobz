from bot import *

@app.route("/trial-vmess", methods=["GET","POST"])
async def vmessTrialz():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			servers = []
			db = get_db()
			lim = db.execute("SELECT limcounted FROM vmess").fetchall()
			cont = db.execute("SELECT counted FROM vmess").fetchall()
			domain = db.execute("SELECT domain FROM vmess").fetchall()
			name = db.execute("SELECT buttonname FROM vmess").fetchall()
			harga = db.execute("SELECT harga FROM vmess").fetchall()
			quota = db.execute("SELECT quota FROM vmess").fetchall()
			a = 0
			for i, j, v, z, l, h in zip(domain, name, harga, cont, lim, quota):
				hargaa = "{:,}".format(harga[a][0])
				servers.append({"host":f"{domain[a][0]},{harga[a][0]},{name[a][0]}","name":f"{name[a][0]} - Rp. {hargaa} - Slot {cont[a][0]}/{lim[a][0]} - Quota {quota[a][0]}GB", "price":harga[a][0]})
				a += 1
			xjs = eval(x)
			return render_template("trial-vmess.html",servers=servers)
		else:
			return redirect("/login")
	elif request.method == "POST":
		x = request.cookies.get("auth")
		if x:
			db = get_db()
			xjs = eval(x)
			telegram = xjs["telegram"]

			saldo = db.execute("SELECT saldo FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			if int(saldo) <= 0:
				flash(Markup("<strong>Trial Error!</strong><br>0 Balance, Can't Create Trial"))
				return redirect("/trial-vmess")
			else:
				user = request.form["username"]
				serverv = request.form.get("server").split(",")
				user = request.form["username"]
#				serverv = request.form.get("server")
				if not user:
					flash(Markup("<strong>Trial Error!</strong><br>Invalid Username"))
#					flash(Markup("Username Tidak Dapat Kosong"))
#					return render_template("trial-vmess.html")
					return redirect("/trial-vmess")
				else:
					res = requests.get("http://"+serverv[0]+":6969/trial-vmess")
					if res.text != "error":
						today = DT.date.today()
						later = today + DT.timedelta(days=1)
						exp = later.strftime("%Y-%m-%d")
						exp = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(exp),"%Y-%m-%d"))
						date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
#						db.execute("INSERT INTO transaksi (protocol,descr,usd,date,email) VALUES (%s,%s,%s,%s,%s)", (f"{serverv} VMess","Trial VMess Account","0",date,email))
						info = []
						infor = []
						print(res.text)
						if len(list(eval(res.text))) == 3:
							acc = f"""TLS Link:<br>
<textarea class="form-control" rows="8" readonly>{eval(res.text)[0]}</textarea><br>
<hr><br>
HTTP Link:<br>
<textarea class="form-control" rows="8" readonly>{eval(res.text)[1]}</textarea><br>
<hr><br>
gRPC Link:<br>
<textarea class="form-control" rows="8" readonly>{eval(res.text)[2]}</textarea><br>"""
							accr = f"""TLS Link:
`{eval(res.text)[0]}`
━━━━━━━━━━━━━━━━
HTTP Link:
`{eval(res.text)[1]}`
━━━━━━━━━━━━━━━━
gRPC Link:
`{eval(res.text)[2]}`"""
						else:
							acc = f"""TLS Link:<br>
<textarea class="form-control" rows="8" readonly>{eval(res.text)[0]}</textarea><br>
<hr><br>
HTTP Link:<br>
<textarea class="form-control" rows="8" readonly>{eval(res.text)[1]}</textarea><br>"""
							accr = f"""TLS Link:
`{eval(res.text)[0]}`
━━━━━━━━━━━━━━━━
HTTP Link:
`{eval(res.text)[1]}`"""
						for g in eval(res.text):
#							print(g)
							rekt = g.replace('vmess://',"")
							rekt2 = base64.b64decode(rekt).decode('ascii')
							rekt3 = json.loads(rekt2)
							try:
								rekt3.pop("add")
								rekt3.pop("aid")
								rekt3.pop("host")
								rekt3.pop("id")
#								rekt3.pop("sni")
#								rekt3.pop("tls")
								rekt3.pop("type")
								rekt3.pop("ps")
								rekt3.pop("v")
							except:
								pass
							for v,k in zip(rekt3.keys(), rekt3.values()):
								info.append(v.capitalize() + " : " + k.capitalize() + "<br>")
								infor.append("• "+v.capitalize() + ": " + k.capitalize() + "\n")
						raw = eval(res.text)[0].replace("vmess://","")
						print(raw)
						single = json.loads(base64.b64decode(raw).decode('ascii'))
						j = f"""<strong>User: {user}<br>
Expiration: {exp}<br>
Remarks: {single["ps"]}<br>
Domain: {single["add"]}<br>
UUID: {single["id"]}<br>
Alter ID: 0<br>
<hr><br>
{"".join(info)}
<hr><br>
{acc}
</strong>"""
						msg = f"""━━━━━━━━━━━━━━━━
• User: `{single["ps"]}`
• Expiration: `{exp}`
• Domain: `{single["add"]}`
• UUID: `{single["id"]}`
• Alter ID: 0
━━━━━━━━━━━━━━━━
{"".join(infor)}
━━━━━━━━━━━━━━━━
{accr}"""
#						await Notif("Trial","VMess",exp,email,"0",server)
						return render_template("trial-vmess.html",result=j)
					else:
						flash(Markup("<strong>Trial Error</strong> User Already Exist"))
						return redirect("/trial-vmess")


