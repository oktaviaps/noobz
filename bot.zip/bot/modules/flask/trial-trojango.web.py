from bot import *

@app.route("/trial-trojango", methods=["GET","POST"])
async def trojangoTrial():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			xjs = eval(x)
			servers = []
			db = get_db()
			lim = db.execute("SELECT limcounted FROM trojango").fetchall()
			cont = db.execute("SELECT counted FROM trojango").fetchall()
			domain = db.execute("SELECT domain FROM trojango").fetchall()
			name = db.execute("SELECT buttonname FROM trojango").fetchall()
			harga = db.execute("SELECT harga FROM trojango").fetchall()
			print(harga)
			a = 0
			for i, j, v, z, l in zip(domain, name, harga, cont, lim):
				hargaa = "{:,}".format(harga[a][0])
				servers.append({"host":f"{domain[a][0]},{harga[a][0]},{name[a][0]}","name":f"{name[a][0]} - Rp. {hargaa} - Slot {cont[a][0]}/{lim[a][0]}", "price":harga[a][0]})
				a += 1
#			z = db.execute("SELECT buttonname FROM trojango").fetchall()
			print(servers)
			return render_template("trial-trojango.html",servers=servers)
		else:
			return redirect("/login")
	elif request.method == "POST":
		x = request.cookies.get("auth")
		if x:
			db = get_db()
			xjs = eval(x)
			telegram = xjs["telegram"]
			saldo = db.execute("SELECT saldo FROM user WHERE member = (?)",(telegram,)).fetchone()[0]
			if int(saldo) <= 0:
				flash(Markup("<strong>trial Error!</strong><br>0 Balance, Can't Create Account"))
				return redirect("/trial-trojango")
			else:
				db = get_db()
				user = request.form["username"]
				serverv = request.form.get("server").split(",")
#				exp = request.form.get("exp").split(",")
				exp = 1
				buttonname = serverv[2]
				domain = serverv[0]
				lim = db.execute("SELECT limcounted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				cont = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				serverv = request.form.get("server").split(",")
				if not user:
					flash(Markup("<strong>Trial Error!</strong><br>Invalid Username"))
					return redirect("/trial-trojango")
				else:
					res = requests.get("http://"+serverv[0]+f":6969/create-trgo?user={user}&exp={exp}")
					if res.text != "error":
						print(res.text)
						x = res.text
						key = re.search("trojan-go://(.*?)@",x).group(1)
						domain = re.search("@(.*?):",x).group(1)
						port = re.search(domain+":(.*?)/",x).group(1)
						remarks = key
						path = re.search("path=(.*?)&",x).group(1)
						try:
							remarks = re.search("#(.*)",x).group(1)
						except:
							remarks = uuid
						today = DT.date.today()
						later = today + DT.timedelta(days=1)
						exp = later.strftime("%Y-%m-%d")
						exp = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(exp),"%Y-%m-%d"))
						date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
						msg = f"""Trial Trojan GO Account<br>
Domain: {serverv[0]}<br>
Remarks: {remarks}<br>
Port: {port}<br>
Key: {key}<br>
Path: {path}<br>
User: {user}<br>
Expiration: {exp}<br>
<hr><br>
Trojan GO Link:<br>
{x.replace(" ","").strip()}
<hr>
"""
#						await Notif("Premium","Trojan",exp,email,salkur,server[0])
						return render_template("trial-trojango.html",result=msg)
					else:
						flash(Markup("<strong>Trial Error</strong> User Already Exist"))
						return redirect("/trial-trojango")
	else:
		return "kontoll"




