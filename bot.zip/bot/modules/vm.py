from bot import *

@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def vmess(event):
    async def vmess_(event, page_num=0):
        db = get_db()
        z = db.execute("SELECT buttonname FROM vmess").fetchall()
        buttons_per_page = 5
        num_pages = (len(z) + buttons_per_page - 1) // buttons_per_page
        start_idx = page_num * buttons_per_page
        end_idx = min(start_idx + buttons_per_page, len(z))
        do = []
        for idx, btn in enumerate(z[start_idx:end_idx], start=start_idx + 1):
            do.append(f"{idx}. `{btn[0]}`")
        if num_pages > 1:
            navigation_buttons = []
            if page_num > 0:
                navigation_buttons.append(Button.inline("◀️ Prev", data=f"prev_{page_num}"))
            if page_num < num_pages - 1:
                navigation_buttons.append(Button.inline("Next ▶️", data=f"next_{page_num}"))
            do.extend(navigation_buttons)
        do.append(["Back to Main Menu"])
        
        await event.edit(text="\n".join("\n".join(page) for page in do))

        async with bot.conversation(event.chat_id) as conv:
            conv = conv.wait_event(events.CallbackQuery)
            buttonname = await conv
            buttonname = buttonname.data.decode("utf-8")

        harga = db.execute("SELECT harga FROM vmess WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        domain = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        quota = db.execute("SELECT quota FROM vmess WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        limitip = db.execute("SELECT limitip FROM vmess WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        lim = db.execute("SELECT limcounted FROM vmess WHERE buttonname = (?)", (buttonname,)).fetchone()[0]
        cont = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)", (buttonname,)).fetchone()[0]

        z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()

        hargaa = "{:,}".format(harga)
        msg = f"""
        **━━━━━━━━━━━━━━━━━━━**
        **⚜ Informasi Server ⚜**
        **━━━━━━━━━━━━━━━━━━━**
        **🔰 Server Name:** `{buttonname}`
        **🔰 ISP:** `{z["isp"]}`
        **🔰 Country:** `{z["country"]}`
        **🔰 Domain:** `{domain}`
        **🔰 Quota:** `{quota} GB`
        **🔰 Harga:** `{hargaa}`
        **🔰 Total Akun Dibuat:** `{cont}/{lim}`
        **━━━━━━━━━━━━━━━━━━━**
        ** Pilih Ya Untuk Lanjut...!! **
        **━━━━━━━━━━━━━━━━━━━**
        """
        await event.edit(msg, buttons=[
            [Button.inline(" Ya ", "y"), Button.inline(" Tidak ", "n")],
            [Button.inline(" 🔙 Back To Menu ", "menu")]
        ])

        async with bot.conversation(event.chat_id) as con:
            con = con.wait_event(events.CallbackQuery)
            con = await con

        if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
            await event.respond("**Dibatalkan.**")
        elif con.data.decode("ascii") == "y":
            async with bot.conversation(event.chat_id) as user:
                await event.edit("**Username: **")
                user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = await user
                user = user.message.message

    await vmess_(event)

@bot.on(events.CallbackQuery(pattern=r"next_(\d+)"))
async def next_page(event):
    await vmess(event, int(event.pattern_match.group(1)) + 1)

@bot.on(events.CallbackQuery(pattern=r"prev_(\d+)"))
async def prev_page(event):
    await vmess(event, int(event.pattern_match.group(1)) - 1)
