from bot import *

@bot.on(events.NewMessage(pattern="(?:.edit|/edit)"))
async def editServ(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a or sender.id == 1810081802:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**⚜ Edit Server Menu ⚜**
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		z = await event.edit(msg,buttons=[
[Button.inline("🍁 SSH Server 🍁","editssh"),
Button.inline("🍁 VMess Server 🍁","editvmess")],
[Button.inline("🍁 Trojan Server 🍁","edittrojan"),
Button.inline("🍁 Trojan WS Server 🍁","edittrojanws")],
[Button.inline("🍁 Trojan GO Server 🍁","edittrojango")]])
#[Button.inline("Reseller Notif","notif")]])
		if not z:
			await event.respond(msg,buttons=[
[Button.inline("🍁 SSH Server 🍁","editssh"),
Button.inline("🍁 VMess Server 🍁","editvmess")],
[Button.inline("🍁 Trojan Server 🍁","edittrojan"),
Button.inline("🍁 Trojan WS Server 🍁","edittrojanws")],
[Button.inline("🍁 Trojan GO Server 🍁","edittrojango")]])
	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")
		else:
			msg = "**Access Denied. Admin Only**"
			await event.respond(msg)

@bot.on(events.CallbackQuery(data=b'editvmess'))
async def editVmess(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a or sender.id == 1810081802:
		z = db.execute("SELECT buttonname FROM vmess").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			do.append([Button.inline(i[0]),
				Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )

		await event.edit("**Select Server**", buttons=do)
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		await event.edit(name, buttons=[
[
Button.inline("Edit Harga","editharga@"+name),
Button.inline("Edit Quota","editquota@"+name)],
[
Button.inline("Edit Limit IP","editlimitip@"+name),
Button.inline("Edit Nama","editnama@"+name)],
[
Button.inline("Edit Domain","editdomain@"+name),
Button.inline("Edit Slot Keseluruhan","editslotall@"+name),
Button.inline("Edit Slot","editslot@"+name)]])
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		name = name.split("@")
		action = name[0]
		server = name[1]
		if action == "editharga":
			current_value = db.execute("SELECT harga FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Harga Sekarang:** `{current_value}`
**Masukkan Harga Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE vmess SET harga = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT harga FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Harga Berhasil Diubah!**

**Harga Sebelumnya:** `{current_value}`
**Harga Baru:** `{new_value}`""")
		elif action == "editquota":
			current_value = db.execute("SELECT quota FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Quota Sekarang:** `{current_value}`
**Masukkan Quota Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE vmess SET quota = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT quota FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Quota Berhasil Diubah!**

**Quota Sebelumnya:** `{current_value}`
**Quota Baru:** `{new_value}`""")
		elif action == "editlimitip":
			current_value = db.execute("SELECT limitip FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Limit IP Sekarang:** `{current_value}`
**Masukkan Limit IP Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE vmess SET limitip = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limitip FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Limit IP Berhasil Diubah!**

**Limit IP Sebelumnya:** `{current_value}`
**Limit IP Baru:** `{new_value}`""")
		elif action == "editnama":
			current_value = db.execute("SELECT buttonname FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Nama Server Sekarang:** `{current_value}`
**Masukkan Nama Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE vmess SET buttonname = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT buttonname FROM vmess WHERE buttonname = (?)",(new_value,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Nama Server Berhasil Diubah!**

**Nama Server Sebelumnya:** `{current_value}`
**Nama Server Baru:** `{new_value}`""")
		elif action == "editdomain":
			current_value = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Domain Server Sekarang:** `{current_value}`
**Masukkan Domain Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE vmess SET domain = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Domain Server Berhasil Diubah!**

**Domain Server Sebelumnya:** `{current_value}`
**Domain Server Baru:** `{new_value}`""")
		elif action == "editslotall":
			current_value = db.execute("SELECT limcounted FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Keseluruhan Sekarang:** `{current_value}`
**Masukkan Slot Keseluruhan Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE vmess SET limcounted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limcounted FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Keseluruhan Berhasil Diubah!**

**Slot Keseluruhan Sebelumnya:** `{current_value}`
**Slot Keseluruhan Baru:** `{new_value}`""")
		elif action == "editslot":
			current_value = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Sekarang:** `{current_value}`
**Masukkan Slot Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE vmess SET counted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Berhasil Diubah!**

**Slot Sebelumnya:** `{current_value}`
**Slot Baru:** `{new_value}`""")


@bot.on(events.CallbackQuery(data=b'editssh'))
async def editssh(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a or sender.id == 1810081802:
		z = db.execute("SELECT buttonname FROM ssh").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			do.append([Button.inline(i[0]),
				Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )

		await event.edit("**Select Server**", buttons=do)
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		await event.edit(name, buttons=[
[
Button.inline("Edit Harga","editharga@"+name),
Button.inline("Edit Pubkey","editpubkey@"+name),
Button.inline("Edit NS","editns@"+name)],
[
Button.inline("Edit Limit IP","editlimitip@"+name),
Button.inline("Edit Nama","editnama@"+name)],
[
Button.inline("Edit Domain","editdomain@"+name),
Button.inline("Edit Slot Keseluruhan","editslotall@"+name),
Button.inline("Edit Slot","editslot@"+name)],
[
Button.inline("Edit Port Dropbear","editportdb@"+name),
Button.inline("Edit Port WS TLS","editportwstls@"+name),
Button.inline("Edit Port WS NTLS","editportwsntls@"+name)],
[Button.inline("Edit LINK","editlink@"+name)]])
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		name = name.split("@")
		action = name[0]
		server = name[1]
		if action == "editharga":
			current_value = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Harga Sekarang:** `{current_value}`
**Masukkan Harga Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET harga = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Harga Berhasil Diubah!**

**Harga Sebelumnya:** `{current_value}`
**Harga Baru:** `{new_value}`""")
		elif action == "editpubkey":
			current_value = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**PubKey Sekarang:** `{current_value}`
**Masukkan PubKey Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET pubkey = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**PubKey Berhasil Diubah!**

**PubKey Sebelumnya:** `{current_value}`
**PubKey Baru:** `{new_value}`""")
		elif action == "editns":
			current_value = db.execute("SELECT ns FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**NS Sekarang:** `{current_value}`
**Masukkan NS Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ns SET pubkey = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT ns FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**NS Berhasil Diubah!**

**NS Sebelumnya:** `{current_value}`
**NS Baru:** `{new_value}`""")
		elif action == "editlimitip":
			current_value = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Limit IP Sekarang:** `{current_value}`
**Masukkan Limit IP Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET limitip = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Limit IP Berhasil Diubah!**

**Limit IP Sebelumnya:** `{current_value}`
**Limit IP Baru:** `{new_value}`""")
		elif action == "editnama":
			current_value = db.execute("SELECT buttonname FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Nama Server Sekarang:** `{current_value}`
**Masukkan Nama Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET buttonname = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT buttonname FROM ssh WHERE buttonname = (?)",(new_value,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Nama Server Berhasil Diubah!**

**Nama Server Sebelumnya:** `{current_value}`
**Nama Server Baru:** `{new_value}`""")
		elif action == "editdomain":
			current_value = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Domain Server Sekarang:** `{current_value}`
**Masukkan Domain Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET domain = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Domain Server Berhasil Diubah!**

**Domain Server Sebelumnya:** `{current_value}`
**Domain Server Baru:** `{new_value}`""")
		elif action == "editslotall":
			current_value = db.execute("SELECT limcounted FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Keseluruhan Sekarang:** `{current_value}`
**Masukkan Slot Keseluruhan Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET limcounted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limcounted FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Keseluruhan Berhasil Diubah!**

**Slot Keseluruhan Sebelumnya:** `{current_value}`
**Slot Keseluruhan Baru:** `{new_value}`""")
		elif action == "editslot":
			current_value = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Sekarang:** `{current_value}`
**Masukkan Slot Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET counted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Berhasil Diubah!**

**Slot Sebelumnya:** `{current_value}`
**Slot Baru:** `{new_value}`""")
		elif action == "editportdb":
			current_value = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Port Dropbear Sekarang:** `{current_value}`
**Masukkan Port Dropbear Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET portdb = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Port Dropbear Berhasil Diubah!**

**Port Dropbear Sebelumnya:** `{current_value}`
**Port Dropbear Baru:** `{new_value}`""")
		elif action == "editportwstls":
			current_value = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Port WS TLS Sekarang:** `{current_value}`
**Masukkan Port WS TLS Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET portwstls = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Port WS TLS Berhasil Diubah!**

**Port WS TLS Sebelumnya:** `{current_value}`
**Port WS TLS Baru:** `{new_value}`""")
		elif action == "editportwsntls":
			current_value = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Port WS NTLS Sekarang:** `{current_value}`
**Masukkan Port WS NTLS Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET portwsntls = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Port WS NTLS Berhasil Diubah!**

**Port WS NTLS Sebelumnya:** `{current_value}`
**Port WS NTLS Baru:** `{new_value}`""")
		elif action == "editlink":
			current_value = db.execute("SELECT link FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Link Sekarang:** `{current_value}`
**Masukkan Link Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE ssh SET link = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT link FROM ssh WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Link Berhasil Diubah!**

**Link Sebelumnya:** `{current_value}`
**Link Baru:** `{new_value}`""")


@bot.on(events.CallbackQuery(data=b'edittrojan'))
async def edittrojan(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a or sender.id == 1810081802:
		z = db.execute("SELECT buttonname FROM trojan").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			do.append([Button.inline(i[0]),
				Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )

		await event.edit("**Select Server**", buttons=do)
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		await event.edit(name, buttons=[
[
Button.inline("Edit Harga","editharga@"+name),
Button.inline("Edit Quota","editquota@"+name)],
[
Button.inline("Edit Limit IP","editlimitip@"+name),
Button.inline("Edit Nama","editnama@"+name)],
[
Button.inline("Edit Domain","editdomain@"+name),
Button.inline("Edit Slot Keseluruhan","editslotall@"+name),
Button.inline("Edit Slot","editslot@"+name)]])
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		name = name.split("@")
		action = name[0]
		server = name[1]
		if action == "editharga":
			current_value = db.execute("SELECT harga FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Harga Sekarang:** `{current_value}`
**Masukkan Harga Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojan SET harga = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT harga FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Harga Berhasil Diubah!**

**Harga Sebelumnya:** `{current_value}`
**Harga Baru:** `{new_value}`""")
		elif action == "editquota":
			current_value = db.execute("SELECT quota FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Quota Sekarang:** `{current_value}`
**Masukkan Quota Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojan SET quota = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT quota FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Quota Berhasil Diubah!**

**Quota Sebelumnya:** `{current_value}`
**Quota Baru:** `{new_value}`""")
		elif action == "editlimitip":
			current_value = db.execute("SELECT limitip FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Limit IP Sekarang:** `{current_value}`
**Masukkan Limit IP Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojan SET limitip = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limitip FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Limit IP Berhasil Diubah!**

**Limit IP Sebelumnya:** `{current_value}`
**Limit IP Baru:** `{new_value}`""")
		elif action == "editnama":
			current_value = db.execute("SELECT buttonname FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Nama Server Sekarang:** `{current_value}`
**Masukkan Nama Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojan SET buttonname = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT buttonname FROM trojan WHERE buttonname = (?)",(new_value,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Nama Server Berhasil Diubah!**

**Nama Server Sebelumnya:** `{current_value}`
**Nama Server Baru:** `{new_value}`""")
		elif action == "editdomain":
			current_value = db.execute("SELECT domain FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Domain Server Sekarang:** `{current_value}`
**Masukkan Domain Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojan SET domain = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT domain FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Domain Server Berhasil Diubah!**

**Domain Server Sebelumnya:** `{current_value}`
**Domain Server Baru:** `{new_value}`""")
		elif action == "editslotall":
			current_value = db.execute("SELECT limcounted FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Keseluruhan Sekarang:** `{current_value}`
**Masukkan Slot Keseluruhan Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojan SET limcounted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limcounted FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Keseluruhan Berhasil Diubah!**

**Slot Keseluruhan Sebelumnya:** `{current_value}`
**Slot Keseluruhan Baru:** `{new_value}`""")
		elif action == "editslot":
			current_value = db.execute("SELECT counted FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Sekarang:** `{current_value}`
**Masukkan Slot Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojan SET counted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT counted FROM trojan WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Berhasil Diubah!**

**Slot Sebelumnya:** `{current_value}`
**Slot Baru:** `{new_value}`""")



@bot.on(events.CallbackQuery(data=b'edittrojanws'))
async def edittrojanws(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a or sender.id == 1810081802:
		z = db.execute("SELECT buttonname FROM trojanws").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			do.append([Button.inline(i[0]),
				Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )

		await event.edit("**Select Server**", buttons=do)
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		await event.edit(name, buttons=[
[
Button.inline("Edit Harga","editharga@"+name),
Button.inline("Edit Quota","editquota@"+name)],
[
Button.inline("Edit Limit IP","editlimitip@"+name),
Button.inline("Edit Nama","editnama@"+name)],
[
Button.inline("Edit Domain","editdomain@"+name),
Button.inline("Edit Slot Keseluruhan","editslotall@"+name),
Button.inline("Edit Slot","editslot@"+name)]])
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		name = name.split("@")
		action = name[0]
		server = name[1]
		if action == "editharga":
			current_value = db.execute("SELECT harga FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Harga Sekarang:** `{current_value}`
**Masukkan Harga Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojanws SET harga = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT harga FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Harga Berhasil Diubah!**

**Harga Sebelumnya:** `{current_value}`
**Harga Baru:** `{new_value}`""")
		elif action == "editquota":
			current_value = db.execute("SELECT quota FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Quota Sekarang:** `{current_value}`
**Masukkan Quota Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojanws SET quota = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT quota FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Quota Berhasil Diubah!**

**Quota Sebelumnya:** `{current_value}`
**Quota Baru:** `{new_value}`""")
		elif action == "editlimitip":
			current_value = db.execute("SELECT limitip FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Limit IP Sekarang:** `{current_value}`
**Masukkan Limit IP Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojanws SET limitip = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limitip FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Limit IP Berhasil Diubah!**

**Limit IP Sebelumnya:** `{current_value}`
**Limit IP Baru:** `{new_value}`""")
		elif action == "editnama":
			current_value = db.execute("SELECT buttonname FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Nama Server Sekarang:** `{current_value}`
**Masukkan Nama Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojanws SET buttonname = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT buttonname FROM trojanws WHERE buttonname = (?)",(new_value,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Nama Server Berhasil Diubah!**

**Nama Server Sebelumnya:** `{current_value}`
**Nama Server Baru:** `{new_value}`""")
		elif action == "editdomain":
			current_value = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Domain Server Sekarang:** `{current_value}`
**Masukkan Domain Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojanws SET domain = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Domain Server Berhasil Diubah!**

**Domain Server Sebelumnya:** `{current_value}`
**Domain Server Baru:** `{new_value}`""")
		elif action == "editslotall":
			current_value = db.execute("SELECT limcounted FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Keseluruhan Sekarang:** `{current_value}`
**Masukkan Slot Keseluruhan Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojanws SET limcounted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limcounted FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Keseluruhan Berhasil Diubah!**

**Slot Keseluruhan Sebelumnya:** `{current_value}`
**Slot Keseluruhan Baru:** `{new_value}`""")
		elif action == "editslot":
			current_value = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Sekarang:** `{current_value}`
**Masukkan Slot Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojanws SET counted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Berhasil Diubah!**

**Slot Sebelumnya:** `{current_value}`
**Slot Baru:** `{new_value}`""")



@bot.on(events.CallbackQuery(data=b'edittrojango'))
async def edittrojango(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a or sender.id == 1810081802:
		z = db.execute("SELECT buttonname FROM trojango").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			do.append([Button.inline(i[0]),
				Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )

		await event.edit("**Select Server**", buttons=do)
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		await event.edit(name, buttons=[
[
Button.inline("Edit Harga","editharga@"+name),
Button.inline("Edit Quota","editquota@"+name)],
[
Button.inline("Edit Limit IP","editlimitip@"+name),
Button.inline("Edit Nama","editnama@"+name)],
[
Button.inline("Edit Domain","editdomain@"+name),
Button.inline("Edit Slot Keseluruhan","editslotall@"+name),
Button.inline("Edit Slot","editslot@"+name)]])
		async with bot.conversation(event.chat_id) as c:
			c = c.wait_event(events.CallbackQuery)
			name = await c
			name = name.data.decode("utf-8")
		name = name.split("@")
		action = name[0]
		server = name[1]
		if action == "editharga":
			current_value = db.execute("SELECT harga FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Harga Sekarang:** `{current_value}`
**Masukkan Harga Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojango SET harga = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT harga FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Harga Berhasil Diubah!**

**Harga Sebelumnya:** `{current_value}`
**Harga Baru:** `{new_value}`""")
		elif action == "editquota":
			current_value = db.execute("SELECT quota FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Quota Sekarang:** `{current_value}`
**Masukkan Quota Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojango SET quota = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT quota FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Quota Berhasil Diubah!**

**Quota Sebelumnya:** `{current_value}`
**Quota Baru:** `{new_value}`""")
		elif action == "editlimitip":
			current_value = db.execute("SELECT limitip FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Limit IP Sekarang:** `{current_value}`
**Masukkan Limit IP Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojango SET limitip = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limitip FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Limit IP Berhasil Diubah!**

**Limit IP Sebelumnya:** `{current_value}`
**Limit IP Baru:** `{new_value}`""")
		elif action == "editnama":
			current_value = db.execute("SELECT buttonname FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Nama Server Sekarang:** `{current_value}`
**Masukkan Nama Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojango SET buttonname = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT buttonname FROM trojango WHERE buttonname = (?)",(new_value,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Nama Server Berhasil Diubah!**

**Nama Server Sebelumnya:** `{current_value}`
**Nama Server Baru:** `{new_value}`""")
		elif action == "editdomain":
			current_value = db.execute("SELECT domain FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Domain Server Sekarang:** `{current_value}`
**Masukkan Domain Server Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojango SET domain = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT domain FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Domain Server Berhasil Diubah!**

**Domain Server Sebelumnya:** `{current_value}`
**Domain Server Baru:** `{new_value}`""")
		elif action == "editslotall":
			current_value = db.execute("SELECT limcounted FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Keseluruhan Sekarang:** `{current_value}`
**Masukkan Slot Keseluruhan Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojango SET limcounted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT limcounted FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Keseluruhan Berhasil Diubah!**

**Slot Keseluruhan Sebelumnya:** `{current_value}`
**Slot Keseluruhan Baru:** `{new_value}`""")
		elif action == "editslot":
			current_value = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.edit(f"""**{server}**
===
**Slot Sekarang:** `{current_value}`
**Masukkan Slot Baru:**""")
			async with bot.conversation(event.chat_id) as c:
				c = c.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				new_value = await c
				new_value = new_value.message.message
			db.execute("UPDATE trojango SET counted = ? WHERE buttonname = ?",(new_value,server,))
			db.commit()
			new_value = db.execute("SELECT counted FROM trojango WHERE buttonname = (?)",(server,)).fetchone()[0]
			await event.reply(f"""**{server}**
===
**Slot Berhasil Diubah!**

**Slot Sebelumnya:** `{current_value}`
**Slot Baru:** `{new_value}`""")

