from bot import *

async def Notif(tipe,protocol,exp,email,price,isp):
	today = DT.date.today()
	date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
	trans = db.execute("SELECT * FROM transaksi").fetchall()
	msg = f"""
**━━━━━━━━━━━━━━━━**
**New transactions | {DOMAIN}**
**━━━━━━━━━━━━━━━━**
**» Transaction counts:** `{str(len(trans))}`
**» Date:** `{date}`
**» Email:** `{email}`
**━━━━━━━━━━━━━━━━**
**» Protocol:** `{protocol}` **|** `{isp}`
**» Type:** `{tipe}`
**» Expiry:** `{exp}`
**» Price:** `{price}`
**━━━━━━━━━━━━━━━━**
"""
	return await client.send_message(CHANNEL_ID,msg)
