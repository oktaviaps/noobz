from bot import *

@app.errorhandler(404)
async def error404(e):
	return render_template("404.html")
