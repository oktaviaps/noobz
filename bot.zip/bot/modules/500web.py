from bot import *

@app.errorhandler(500)
async def error404(e):
	return render_template("500.html")
