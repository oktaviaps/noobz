from bot import *

@app.route("/callback", methods=["GET","POST"])
async def callback():
	print(request.headers.get("X-Callback-Signature"))
	signStr = request.data.decode('ascii')
	signature = hmac.new(bytes(privateKey,'latin-1'), bytes(signStr,'latin-1'), hashlib.sha256).hexdigest()
	callSignature = request.headers.get("X-Callback-Signature")
	js = json.loads(signStr)
	db = get_db()
	if signature == callSignature:
		payload = { "reference": js["reference"] }
		headers = { "Authorization": "Bearer " + apiKey }
		result = requests.get("https://tripay.co.id/api/transaction/detail", params=payload, headers=headers)
		response = result.text
		js = json.loads(response)
		status = js["data"]["status"]
		print(status)
		signDb = db.execute("SELECT sign FROM tripay WHERE sign = ?", (callSignature,)).fetchone()
		if signDb != None:
			signDb = signDb[0]
		else:
			signDb = "None"
		if status == "PAID" and callSignature != signDb:
			fee = int(js["data"]["fee_customer"])
			db.execute("INSERT INTO tripay (sign) VALUES (?)",(callSignature,))
			email = js["data"]["customer_email"]
			saldo = int(js["data"]["amount"])
			saldo = saldo - fee
			bonus = saldo * 0.06
			saldo = saldo + bonus
			current_saldo = db.execute("SELECT saldo FROM user WHERE email = ?", (email,)).fetchone()[0]
			db.execute("UPDATE user SET saldo = ? WHERE email = ?",(int(current_saldo)+int(saldo),email,))
			db.commit()
			await TripayNotif(email,saldo)
			return { "success": True }
		else:
			return "None"
	else:
		return "Invalid signature"

