'''
#[Button.inline("Reseller Notif","notif")]])

from bot import *

@bot.on(events.CallbackQuery(data=b'menu'))
@bot.on(events.NewMessage(pattern="(?:.menu|/menu)$"))
async def menuuu(event):
	print("Yes..")
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a:
		print("Yow")
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**⚜ 👨‍💻Admin Panel Menu ⚜**
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 👥Total Member/Reseller:** `{member}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 🤖Bot Version:** `v1.0`
**🔰 🤖Bot Uptime:** `{uptime}`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		print(msg)
		await event.respond(msg, buttons=[
[Button.inline(" Panel Create Account ","submenu1"),
Button.inline(" Edit Quota Jing ","quotaq")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
#		print(z)
#		if not z:
		"""			print("Yoww")
			await event.reply(msg,buttons=[
[Button.inline(" Panel Create Account ","submenu1"),
Button.inline(" Edit Quota Jing ","quotaq")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
"""
	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.reply("**Akses Ditolak ❌**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**⚜ 👤Reseller Panel Menu ⚜**
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 👤Reseller Information:**
**🔰 📧Email:** `{val["email"]}`
**🔰 🆔Member ID:** `{val["member"]}`
**🔰 💵Saldo:** `{val["saldo"]}`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			x = await event.respond(msg, buttons=[
[Button.inline(" Panel Create Account ","submenu1")],
#Button.inline(" Cek Server ","cekserver")],
[Button.inline("Top Up Saldo [Tripay]","topup")]])
			if not x:
				await event.reply(msg, buttons=[
[Button.inline(" Panel Create Account ","submenu1")],
#Button.inline(" Cek Server ","cekserver")],
[Button.inline("Top Up Saldo [Tripay]","topup")]])
'''
