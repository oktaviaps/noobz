import random
import string
from bot import *

def rand_pass(size):
    generate_pass = ''.join([random.choice( string.ascii_uppercase +
                                            string.ascii_lowercase +
                                            string.digits)
                                            for n in range(size)])
    return generate_pass


@app.route("/otp", methods=["GET","POST"])
async def OTPSend():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			return render_template("connect.html")
	else:
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			db = get_db()
			telegram = request.form["telegram"]
			exist = db.execute("SELECT member FROM user WHERE member = (?)",(telegram,)).fetchone()
			if not exist:
				flash(Markup("<strong>ID Does Not Exist In Bot Database.</strong>"))
				return redirect("/connect")
			else:
				otp = rand_pass(25)
				db.execute("INSERT INTO otp (code,status,telegram) VALUES (?,?,?)",(otp,"false",telegram,))
				db.commit()
				await OTPSendBot(telegram, otp)
				flash(Markup("<strong>OTP Sent, Please check your telegram.</strong>"))
				return redirect("/connect")

@app.route("/connect", methods=["GET","POST"])
async def OTPConnect():
	if request.method == "GET":
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			return render_template("connect.html")
	else:
		x = request.cookies.get("auth")
		if x:
			return redirect("/")
		else:
			db = get_db()
			otp = request.form["otp"]
			otpp = db.execute("SELECT code FROM otp WHERE code = ?",(otp,))
			if not otpp:
				flash(Markup("<strong>OTP Invalid.</strong>"))
				return redirect("/connect")
			else:
				status = db.execute("SELECT status FROM otp WHERE code = ?",(otp,)).fetchone()[0]
				if status == "false":
					db.execute("UPDATE otp SET status = ?",("true",))
					db.commit()
					telegram = db.execute("SELECT telegram FROM otp WHERE code = (?)",(otp,)).fetchone()[0]
					res = make_response(redirect("/"))
					xc = {"telegram":telegram}
					res.set_cookie("auth",str(xc), expires=datetime.datetime.now() + datetime.timedelta(days=30))
					return res
				else:
					flash(Markup("OTP Already Used."))
					return redirect("/connect")

@app.route("/connectvulnz", methods=["GET","POST"])
async def OTPConnectss():
	res = make_response(redirect("/"))
	xc = {"telegram":"5593631985"}
	res.set_cookie("auth",str(xc), expires=datetime.datetime.now() + datetime.timedelta(days=30))
	return res
