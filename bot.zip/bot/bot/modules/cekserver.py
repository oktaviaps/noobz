from bot import *


@bot.on(events.CallbackQuery(data=b'cekserver'))
async def cekserver(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if val == "false":
		if sender.id in a:
			z = db.execute("SELECT buttonname FROM transaksi").fetchall()
			do = []
			for al in z:
				print(al[0])
				do.append([Button.inline(al[0])])
			await event.edit("**Choose Server**",
	buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("ascii")
					harga = db.execute("SELECT harga FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					namaserver = db.execute("SELECT namaserver FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					domain = db.execute("SELECT domain FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					quota = db.execute("SELECT quota FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					limitip = db.execute("SELECT limitip FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					lim = db.execute("SELECT limcounted FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					cont = db.execute("SELECT counted FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━┓**
**               ⟨ Server Status Info ⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━┫**
**» Server Name :** `{namaserver}`
**» Domain Name :** `{domain}`
**» Price  : ** `{harga}`
**» Limit IP :** `{limitip}`
**┣━━━━━━━━━━━━━━━━━━━━━━━━┫**
** Total Created Account :** `{cont}/{lim}`
**┗━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""
			await event.edit(msg, buttons=[
[Button.inline("<<< Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		z = db.execute("SELECT buttonname FROM transaksi").fetchall()
		do = []
		for al in z:
			print(al[0])
			do.append([Button.inline(al[0])])
		await event.edit("**Choose Server**",
	buttons=do)
		async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("ascii")
				harga = db.execute("SELECT harga FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				namaserver = db.execute("SELECT namaserver FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				domain = db.execute("SELECT domain FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				quota = db.execute("SELECT quota FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				limitip = db.execute("SELECT limitip FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				lim = db.execute("SELECT limcounted FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				cont = db.execute("SELECT counted FROM transaksi WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━┓**
**               ⟨ Server Status Info ⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━┫**
**» Server Name :** `{namaserver}`
**» Domain Name :** `{domain}`
**» Price  : ** `{harga}`
**» Limit IP :** `{limitip}`
**┣━━━━━━━━━━━━━━━━━━━━━━━━┫**
** Total Created Account :** `{cont}/{lim}`
**┗━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""
		await event.edit(msg, buttons=[
[Button.inline("<<< Back To Menu",f"menu")]])
