from bot import *

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id not in a:
		val = valid(sender.id)
		async with bot.conversation(event.chat_id) as num:
			await event.edit("**Nominal TopUp (Minimal 20.000): **")
			num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			num = await num
			num = num.message.message.replace(".","")
		if int(num) < 20000:
			await event.respond("**Minimum Topup 20.000 **")
		else:
			amount = num
		signStr = "{}{}{}".format(merchant_code, merchant_ref, amount)
		signature = hmac.new(bytes(privateKey,'latin-1'), bytes(signStr,'latin-1'), hashlib.sha256).hexdigest()
		url = "https://tripay.co.id/api/transaction/create"
		head = {"Authorization": "Bearer "+apiKey}
		data = {
	"method":"QRIS2",
        "amount":amount,
        "merchant_ref": merchant_ref,
        "customer_name":sender.id,
        "customer_email":val["email"],
        "return_url":"http://example.com/",
	"expired_time":expiry,
	"signature":signature
	}

		order_items = [
    {
      'sku': 'TopUp',
      'name': f'TopUp Saldo Nominal {amount}',
      'price': amount,
      'quantity': 1,
      'product_url': 'https://example.com/',
      'image_url': 'null'
    }
  ]
	i = 0
	for item in order_items:
		for k in item:
			data['order_items['+ str(i) +']['+ str(k) +']'] = item[k]
		i += 1
	result = requests.post("https://tripay.co.id/api/transaction/create", data=data, headers=head)
	response = result.text
	js = json.loads(response)
	if result.status_code == 200:
		qr = requests.get(js["data"]["qr_url"]).content
		with open("qr.png","wb") as w:
			w.write(qr)
		await event.reply(f"""**Silahkan scan QR diatas dan lakukan pembayaran.**
**Nominal TopUp:** Rp. `{amount}`
**Metode pembayaran:** `QRIS`
**Atau Klik link dibawah untuk melanjutkan pembayaran**

**NOTE: tidak ada notifikasi setelah anda membayar, cek saldo anda jika sudah membayar.**""",file="qr.png",
		buttons=[[Button.url("Lanjutkan di TriPay",
		js["data"]["checkout_url"])]])
	else:
		return response

