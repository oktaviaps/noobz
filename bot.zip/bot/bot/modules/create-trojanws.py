from bot import *

@bot.on(events.CallbackQuery(data=b'rentrws'))
async def rentrws(event):
		async def rentrws(event):
			z = db.execute("SELECT buttonname FROM trojanws").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("utf-8")
					harga = db.execute("SELECT harga FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					domain = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
					r = requests.get("http://"+domain+":6969/cektr").text
					all_ = r.split("\n")
					all_list = []
					for x in all_:
						all_list.append("`"+x+"`")
						y = "\n".join(all_list)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ USER LIST TROJAN  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
{y}
**Choose User Number**
"""
					await event.respond(msg)
			async with bot.conversation(event.chat_id) as num:
					await event.edit()
					num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					num = await num
					num = num.message.message
			async with bot.conversation(event.chat_id) as user:
					await event.reply("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")],
[Button.inline("60 Day","60")],
[Button.inline("90 Day","90")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
				if exp == "30":
					min = harga
				elif exp == "60":
					min = harga*2
				elif exp == "90":
					min = harga*3
			if int(val["saldo"]) < min:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				param = f":6969/rentr?num={num}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						db.execute("UPDATE user SET created = ? WHERE member = ?",(int(val["created"])+int(1),sender.id,))
						count = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojanws SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					print(r)
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ Successfully Renewed ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Client Name:** `{user}`
**🔰 🗓 Extendted:** `{exp} Days`
**━━━━━━━━━━━━━━━━━━━**
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					dat = {
				"email":val["email"],
                                "protocol":"Renew Trojan-ws",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		data = event.data.decode("ascii").split("-")[0]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				val = {"saldo":"100000000"}
				await rentrws(event)
		else:
			await rentrws(event)
			
@bot.on(events.CallbackQuery(data=b'trojanws-trial'))
async def trojanwstrial(event):
		async def trojanwstrial_(event):
			z = db.execute("SELECT buttonname FROM trojanws").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				domain = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f":6969/trial-trojan"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(0),sender.id,))
						count = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojanws SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					x = r.text.replace('[','').replace(']','').replace('"',
'').split(',')
					print(x)
					if len(list(x)) == 2:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg1 = f"""
proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: ws
    ws-opts:
      path: /trojan
      headers:
        Host: {domain}
    udp: true

proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: grpc
    grpc-opts:
      grpc-service-name: trojan
    udp: true
"""
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ TRIAL Trojan-WS  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port TLS:** `443`
**🔰 UUID:** `{uuid}`
**🔰 Encryption:** `none`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 NetWork:** `GRPC/TLS`
**🔰 Path:** `{path}`
**🔰 ServiceName:** `trojan`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN WS WS Url:**
  `{x[0].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN GRPC  Url:**
  `{x[1].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					elif len(list(x)) == 1:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ TRIAL Trojan-WS  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port TLS:** `443`
**🔰 UUID:** `{uuid}`
**🔰 Encryption:** `none`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 NetWork:** `TLS`
**🔰 Path:** `{path}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN WS Url:**
  `{x[0].replace(" ","").strip()}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""

					await event.respond(msg)
					with open('bot/clash_config.txt', 'a') as save:
						save.write(f"{msg1}")
					file = await bot.upload_file('bot/clash_config.txt')
					await bot.send_file(event.chat_id, file, force_document=True)  
					os.remove("bot/clash_config.txt")
					
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trojanwstrial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trojanwstrial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-trojanws'))
async def trojanws(event):
	async def trojanws_(event):
		z = db.execute("SELECT buttonname FROM trojanws").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga = db.execute("SELECT harga FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		quota = db.execute("SELECT quota FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		limitip = db.execute("SELECT limitip FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim); print(limitip)
		hargaa = "{:,}".format(harga)
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Informasi Server ⚜**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Quota:** `{quota} GB`
**🔰 Harga:** `{hargaa}`
**🔰 Total Akun Dibuat:** `{cont}/{lim}`
**━━━━━━━━━━━━━━━━━━━**
** Pilih Ya Untuk Lanjut...!! **
**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")],
[Button.inline("60 Day","60")],
[Button.inline("90 Day","90")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
				if exp == "30":
					min = harga
				elif exp == "60":
					min = harga*2
				elif exp == "90":
					min = harga*3
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < min:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				param = f":6969/trojan-create?user={user}&quota={quota}&limitip={limitip}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						db.execute("UPDATE user SET created = ? WHERE member = ?",(int(val["created"])+int(1),sender.id,))
						count = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojanws SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					x = r.text.replace('[','').replace(']','').replace('"',
'').split(',')
					print(x)
					if len(list(x)) == 2:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg1 = f"""
proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: ws
    ws-opts:
      path: /trojan
      headers:
        Host: {domain}
    udp: true

proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: grpc
    grpc-opts:
      grpc-service-name: trojan
    udp: true
"""
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ Trojan-WS  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port TLS:** `443`
**🔰 UUID:** `{uuid}`
**🔰 Encryption:** `none`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 NetWork:** `GRPC/TLS`
**🔰 Path:** `{path}`
**🔰 ServiceName:** `trojan`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN WS WS Url:**
  `{x[0].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN GRPC  Url:**
  `{x[1].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					elif len(list(x)) == 1:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ Trojan-WS ACCOUNT ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port TLS:** `443`
**🔰 UUID:** `{uuid}`
**🔰 Encryption:** `none`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 NetWork:** `TLS`
**🔰 Path:** `{path}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN WS Url:**
  `{x[0].replace(" ","").strip()}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					with open('bot/clash_config.txt', 'a') as save:
						save.write(f"{msg1}")
					file = await bot.upload_file('bot/clash_config.txt')
					await bot.send_file(event.chat_id, file, force_document=True)  
					os.remove("bot/clash_config.txt")
					
					dat = {
				"email":val["email"],
                                "protocol":"Trojan-ws",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await trojanws_(event)
	else:
		await trojanws_(event)

@bot.on(events.CallbackQuery(data=b'trwsmenu'))
async def trojanwsmenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namastrws()
	har = hargastrws()
	serv = []
	for x, y in zip(ser, har):
		print(x, y)
		y = "{:,}".format(y)
		serv.append(f"**🔰 {x}  ** `Rp. {y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Trojan-WS Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[
[Button.inline("☘ Created Trojan ☘","create-trojanws"),
Button.inline("☘ Created Trial Trojan ☘","trojanws-trial")],
[Button.inline("☘ Renew Trojan Account ☘","rentrws")],
[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Trojan-WS Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg, buttons=[
[Button.inline("☘ Created Trojan ☘","create-trojanws"),
Button.inline("☘ Created Trial Trojan ☘","trojanws-trial")],
[Button.inline("☘ Renew Trojan Account ☘","rentrws")],
[Button.inline("🔙 Back To Menu",f"menu")]])


