from bot import *

@bot.on(events.CallbackQuery(data=b'submenu'))
async def submenu(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	total = domains()
	ser = namas()
	har = hargas()
	serv = []
	for x, y in zip(ser, har):
		print(x, y)
		serv.append(f"**🔰 {x}  ** `Rp.{y}`\n")
	
	if sender.id in a:
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⚜ Create Account Menu ⚜**
**━━━━━━━━━━━━━━━━**
**🔰 🖥Total Server:** `{total}`
{"".join(serv)}


**━━━━━━━━━━━━━━━━**
"""
		z = await event.edit(msg,buttons=[
[Button.inline("Vmess","vmenu"),
Button.inline("Trojan","tmenu")],
[Button.inline("SSH","smenu")],
[Button.inline(" Back To Menu","menu")]])
#[Button.inline("Reseller Notif","notif")]])
		if not z:
			await event.respond(msg,buttons=[
[Button.inline("Vmess","vmenu"),
Button.inline("Trojan","tmenu")],
[Button.inline("SSH","smenu")],
[Button.inline(" Back To Menu","menu")]])

	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⚜ Create Account Menu ⚜**
**━━━━━━━━━━━━━━━━**
**🔰 🖥Total Server:** `{total}`
**{serv} **
**🔰 💵Saldo Kamu:** `{val["saldo"]}`
**━━━━━━━━━━━━━━━━**
"""
			x = await event.edit(msg, buttons=[
[Button.inline("Vmess","vmenu"),
Button.inline("Trojan","tmenu")],
[Button.inline("SSH","smenu")],
[Button.inline(" Back To Menu","menu")]])
			if not x:
				await event.respond(msg, buttons=[
[Button.inline("Vmess","vmenu"),
Button.inline("Trojan","tmenu")],
[Button.inline("SSH","smenu")],
[Button.inline(" Back To Menu","menu")]])
