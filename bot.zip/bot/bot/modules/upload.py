from bot import *

@bot.on(events.CallbackQuery(data=b'upload'))
async def upload(event):
	async def upload_(event):
		me = await bot.get_me()
		async with bot.conversation(event.chat_id) as con:
			await event.reply("**Upload File:**")
			file = con.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			file = await file
			file = file.message.media
		file = await event.client.download_media(file,"configs/")
		file = base64.b64encode(file.encode("ascii")).decode("ascii")
		msg = f"""
**Successfully Uploaded**

**URL:** `t.me/{me.username}?start={file}`
"""
		await event.reply(msg)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await upload_(event)
	else:
		await event.answer("Akses Ditolak!",alert=True)
