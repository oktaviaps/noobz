from bot import *

@bot.on(events.CallbackQuery(data=b'reboot'))
@bot.on(events.NewMessage(pattern="(?: /reboot|.reboot)$"))
async def reboot(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**⚜ 👨‍💻Admin Panel Menu ⚜**
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 👥Total Member/Reseller:** `{member}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 🤖Bot Version:** `v1.0`
**🔰 🤖Bot Uptime:** `{uptime}`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		z = await event.edit(buttons=[
[Button.inline(" Reboot SSH Server ","serverssh"),
Button.inline(" Reboot VMESS Server  ","servervmess")],
[Button.inline(" Reboot TROJAN-WS Server ","servertrojanws"),
Button.inline(" Reboot TROJAN-GFW Server ","servertrojangfw")],
[Button.inline(" Reboot TROJAN-GO Server ","servertrojango")]])
#[Button.inline("Reseller Notif","notif")]])
		if not z:
			await event.respond(buttons=[
[Button.inline(" Reboot SSH Server ","serverssh"),
Button.inline(" Reboot VMESS Server  ","servervmess")],
[Button.inline(" Reboot TROJAN-WS Server ","servertrojanws"),
Button.inline(" Reboot TROJAN-GFW Server ","servertrojangfw")],
[Button.inline(" Reboot TROJAN-GO Server ","servertrojango")]])
	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")
		else:
			x = await event.edit(buttons=[
[Button.inline(" Reboot SSH Server ","serverssh"),
Button.inline(" Reboot VMESS Server  ","servervmess")],
[Button.inline(" Reboot TROJAN-WS Server ","servertrojanws"),
Button.inline(" Reboot TROJAN-GFW Server ","servertrojangfw")],
[Button.inline(" Reboot TROJAN-GO Server ","servertrojango")]])
			if not x:
				await event.respond(buttons=[
[Button.inline(" Reboot SSH Server ","serverssh"),
Button.inline(" Reboot VMESS Server  ","servervmess")],
[Button.inline(" Reboot TROJAN-WS Server ","servertrojanws"),
Button.inline(" Reboot TROJAN-GFW Server ","servertrojangfw")],
[Button.inline(" Reboot TROJAN-GO Server ","servertrojango")]])
