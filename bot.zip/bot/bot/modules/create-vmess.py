from bot import *

@bot.on(events.CallbackQuery(data=b'renvms'))
async def renvms(event):
		async def renvms(event):
			z = db.execute("SELECT buttonname FROM vmess").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("utf-8")
					harga = db.execute("SELECT harga FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					domain = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
					r = requests.get("http://"+domain+":6969/cekvm").text
					all_ = r.split("\n")
					all_list = []
					for x in all_:
						all_list.append("`"+x+"`")
						y = "\n".join(all_list)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ USER LIST VMESS  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
{y}
**Choose User Number**
"""
					await event.respond(msg)
			async with bot.conversation(event.chat_id) as num:
					await event.edit()
					num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					num = await num
					num = num.message.message
			async with bot.conversation(event.chat_id) as user:
					await event.reply("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")],
[Button.inline("60 Day","60")],
[Button.inline("90 Day","90")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
				if exp == "30":
					min = harga
				if exp == "60":
					min = harga*2
				if exp == "90":
					min = harga*3
			if int(val["saldo"]) < min:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				param = f":6969/renws?num={num}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						db.execute("UPDATE user SET created = ? WHERE member = ?",(int(val["created"])+int(1),sender.id,))
						count = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE vmess SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					print(r)
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ Successfully Renewed ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Client Name:** `{user}`
**🔰 🗓 Extendted:** `{exp} Days`
**━━━━━━━━━━━━━━━━━━━**
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					dat = {
				"email":val["email"],
                                "protocol":"Renew VMess",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Not Found`, `Server Error`
""")
				
					
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		data = event.data.decode("ascii").split("-")[0]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				val = {"saldo":"100000000"}
				await renvms(event)
		else:
			await renvms(event)
			

@bot.on(events.CallbackQuery(data=b'vmess-trial'))
async def vmesstrial(event):
		async def vmesstrial_(event):
			z = db.execute("SELECT buttonname FROM vmess").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				domain = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
				param = f":6969/trial-vmess"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(0),sender.id,))
						count = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE vmess SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					x = r.text.replace("[","").replace("]","").replace("'",
"").split(",")
					print(x)
					if len(list(x)) == 3:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg1 = f"""
proxies:
  - name: {z["ps"]}
    server: {z["add"]}
    port: 443
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: true
    skip-cert-verify: true
    servername: bug.com
    network: ws
    ws-opts:
      path: /vmess
      headers:
        Host: {z["add"]}
    udp: true


proxies:
  - name: {z["ps"]}
    server: {z["add"]}
    port: 80
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: false
    skip-cert-verify: true
    servername: bug.com
    network: ws
    ws-opts:
      path: /vmess
      headers:
        Host: {z["add"]}
    udp: true

proxies:
  - name: {z["ps"]}
    server: {z["add"]}`
    port: 443
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: true
    skip-cert-verify: true
    servername: bug.com
    network: grpc
    grpc-opts:
      grpc-service-name: vmess
    udp: true
"""
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ VMESS TRIAL ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{z["ps"]}`
**🔰 Domain:** `{z["add"]}`
**🔰 Port TLS:** `{z["port"]}`
**🔰 Port HTTP:** `{z1["port"]}`
**🔰 UUID:** `{z["id"]}`
**🔰 Alter ID:** `{z["aid"]}`
**🔰 Security:** `Auto`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 Path:** `{z["path"]}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TLS VMESS Url:**
`{x[0].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 HTTP VMESS Url:**
`{x[1].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 GRPC VMESS Url:**
`{x[2].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					elif len(list(x)) == 2:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ VMESS TRIAL ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{z["ps"]}`
**🔰 Domain:** `{z["add"]}`
**🔰 Port TLS:** `{z["port"]}`
**🔰 Port HTTP:** `{z1["port"]}`
**🔰 UUID:** `{z["id"]}`
**🔰 Alter ID:** `{z["aid"]}`
**🔰 Security:** `Auto`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 Path:** `{z["path"]}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TLS VMESS Url:**
`{x[0].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 HTTP VMESS Url:**
`{x[1].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					with open('bot/clash_config.txt', 'a') as save:
						save.write(f"{msg1}")
					file = await bot.upload_file('bot/clash_config.txt')
					await bot.send_file(event.chat_id, file, force_document=True)  
					os.remove("bot/clash_config.txt")
					
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await vmesstrial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await vmesstrial_(event)
		
		
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def vmess(event):
	async def vmess_(event):
		z = db.execute("SELECT buttonname FROM vmess").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga = db.execute("SELECT harga FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		#namaserver = db.execute("SELECT namaserver FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		quota = db.execute("SELECT quota FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		limitip = db.execute("SELECT limitip FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim); print(limitip)
		hargaa = "{:,}".format(harga)
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Informasi Server ⚜**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Quota:** `{quota} GB`
**🔰 Harga:** `{hargaa}`
**🔰 Total Akun Dibuat:** `{cont}/{lim}`
**━━━━━━━━━━━━━━━━━━━**
** Pilih Ya Untuk Lanjut...!! **
**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")],
[Button.inline("60 Day","60")],
[Button.inline("90 Day","90")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
				if exp == "30":
					min = harga
				if exp == "60":
					min = harga*2
				if exp == "90":
					min = harga*3
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < min:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				param = f":6969/create-vmess?user={user}&quota={quota}&limitip={limitip}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						db.execute("UPDATE user SET created = ? WHERE member = ?",(int(val["created"])+int(1),sender.id,))
						count = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE vmess SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					x = r.text.replace("[","").replace("]","").replace("'",
"").split(",")
					print(x)
					if len(list(x)) == 3:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg1 = f"""
proxies:
  - name: {z["ps"]}
    server: {z["add"]}
    port: 443
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: true
    skip-cert-verify: true
    servername: bug.com
    network: ws
    ws-opts:
      path: /vmess
      headers:
        Host: {z["add"]}
    udp: true


proxies:
  - name: {z["ps"]}
    server: {z["add"]}
    port: 80
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: false
    skip-cert-verify: true
    servername: bug.com
    network: ws
    ws-opts:
      path: /vmess
      headers:
        Host: {z["add"]}
    udp: true

proxies:
  - name: {z["ps"]}
    server: {z["add"]}`
    port: 443
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: true
    skip-cert-verify: true
    servername: bug.com
    network: grpc
    grpc-opts:
      grpc-service-name: vmess
    udp: true
"""
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ VMESS ACCOUNT ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{z["ps"]}`
**🔰 Domain:** `{z["add"]}`
**🔰 Port TLS:** `{z["port"]}`
**🔰 Port HTTP:** `{z1["port"]}`
**🔰 UUID:** `{z["id"]}`
**🔰 Alter ID:** `{z["aid"]}`
**🔰 Security:** `Auto`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 Path:** `{z["path"]}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TLS VMESS Url:**
`{x[0].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 HTTP VMESS Url:**
`{x[1].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 GRPC VMESS Url:**
`{x[2].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					elif len(list(x)) == 2:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ VMESS ACCOUNT ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{z["ps"]}`
**🔰 Domain:** `{z["add"]}`
**🔰 Port TLS:** `{z["port"]}`
**🔰 Port HTTP:** `{z1["port"]}`
**🔰 UUID:** `{z["id"]}`
**🔰 Alter ID:** `{z["aid"]}`
**🔰 Security:** `Auto`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 Path:** `{z["path"]}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TLS VMESS Url:**
`{x[0].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 HTTP VMESS Url:**
`{x[1].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					with open('bot/clash_config.txt', 'a') as save:
						save.write(f"{msg1}")
					file = await bot.upload_file('bot/clash_config.txt')
					await bot.send_file(event.chat_id, file, force_document=True)  
					os.remove("bot/clash_config.txt")
					
					dat = {
				"email":val["email"],
                                "protocol":"VMess",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await vmess_(event)
	else:
		await vmess_(event)
		
		
@bot.on(events.CallbackQuery(data=b'vmess-menu'))
async def vmenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namas()
	har = hargas()
	serv = []
	for x, y in zip(ser, har):
		print(x, y)
		y = "{:,}".format(y)
		serv.append(f"**🔰 {x}  ** `Rp. {y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Vmess Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[
[Button.inline("☘ Created Vmess ☘","create-vmess"),
Button.inline("☘ Created Trial Vmess ☘","vmess-trial")],
[Button.inline("☘ Renew Vmess Account ☘","renvms")],
[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Vmess Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg, buttons=[
[Button.inline("☘ Created Vmess ☘","create-vmess"),
Button.inline("☘ Created Trial Vmess ☘","vmess-trial")],
[Button.inline("☘ Renew Vmess Account ☘","renvms")],
[Button.inline("🔙 Back To Menu",f"menu")]])


