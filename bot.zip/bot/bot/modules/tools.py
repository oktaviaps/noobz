from bot import *

@bot.on(events.NewMessage(pattern="(?:.restart|/restart) (.*)"))
async def restart(event):
	if event:
		sender = await event.get_sender()
		data = event.pattern_match.group(1)
		dom = data.split(":")[0]
		z = requests.get(f"http://ip-api.com/json/{dom}?fields=status").json()
		m  = f"""{z["status"]}"""
		msg = f""" 
**━━━━━━━━━━━━━━━━**
**Restart Service Xray Logs**
**━━━━━━━━━━━━━━━━**
**» Username:** @{sender.username}
**» Domain:** `{dom}`
**━━━━━━━━━━━━━━━━**
"""
		if m == "success":
			u = requests.get("http://"+dom+":6969/restart").text
			if u == "done":
				await event.respond("**Restarting Service Done**")
				await event.client.send_message(LOGS,msg)
			else:
				await event.respond("**Restarting Service Failed**")
		else:
			await event.respond("**No Host**")
@bot.on(events.NewMessage(pattern="(?:.reboot|/reboot) (.*)"))
async def reboot(event):
	if event:
		sender = await event.get_sender()
		data = event.pattern_match.group(1)
		dom = data.split(":")[0]
		z = requests.get(f"http://ip-api.com/json/{dom}?fields=status").json()
		m  = f"""{z["status"]}"""
		msg = f""" 
**━━━━━━━━━━━━━━━━**
**      Servers Rebooted**
**━━━━━━━━━━━━━━━━**
**» Username:** @{sender.username}
**» Domain:** `{dom}`
**━━━━━━━━━━━━━━━━**
"""
		if m == "success":
			u = requests.get("http://"+dom+":6969/reboot").text
			if u == "done":
				await event.respond("**Reboot Servers Done**")
				await event.client.send_message(LOGS,msg)
			else:
				await event.respond("**Reboot Servers Failed**")
		else:
			await event.respond("**No Host**")
			
@bot.on(events.NewMessage(pattern="(?:.warp|/warp) (.*)"))
async def warp(event):
	if event:
		sender = await event.get_sender()
		data = event.pattern_match.group(1)
		dom = data.split(":")[0]
		z = requests.get(f"http://ip-api.com/json/{dom}?fields=status").json()
		m  = f"""{z["status"]}"""
		msg = f""" 
**━━━━━━━━━━━━━━━━**
**    Restart Warp Service **
**━━━━━━━━━━━━━━━━**
**» Username:** @{sender.username}
**» Domain:** `{dom}`
**━━━━━━━━━━━━━━━━**
"""
		if m == "success":
			u = requests.get("http://"+dom+":6969/warp").text
			if u == "done":
				await event.respond("**Restarting Warp Service Done **")
				await event.client.send_message(LOGS,msg)
			else:
				await event.respond("**Restarting Warp Service Failed**")
		else:
			await event.respond("**No Host**")
  
@bot.on(events.NewMessage(pattern="(?:.kill|/kill) (.*)"))
async def kill(event):
	if event:
		sender = await event.get_sender()
		data = event.pattern_match.group(1)
		dom = data.split(":")[0]
		z = requests.get(f"http://ip-api.com/json/{dom}?fields=status").json()
		m  = f"""{z["status"]}"""
		msg = f""" 
**━━━━━━━━━━━━━━━━**
**    Servers Modyaaar **
**━━━━━━━━━━━━━━━━**
**» Username:** @{sender.username}
**» Domain:** `{dom}`
**━━━━━━━━━━━━━━━━**
"""
		if m == "success":
			u = requests.get("http://"+dom+":6969/kill").text
			if u == "done":
				await event.respond("**Modyar Deh **")
				await event.client.send_message(LOGS,msg)
			else:
				await event.respond("**Yah Gatot**")
		else:
			await event.respond("**No Host**")
  
  

@bot.on(events.NewMessage(pattern="(?:.trialvm|/trialvm) (.*)"))  
async def vmesstrials(event):
		async def vmesstrials_(event):
				data = event.pattern_match.group(1)
				domain = data.split(":")[0]
				param = f":6969/trial-vmess"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(0),sender.id,))
						count = db.execute("SELECT counted FROM vmess WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE vmess SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					x = r.text.replace("[","").replace("]","").replace("'",
"").split(",")
					print(x)
					if len(list(x)) == 3:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg1 = f"""
proxies:
  - name: {z["ps"]}
    server: {z["add"]}
    port: 443
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: true
    skip-cert-verify: true
    servername: bug.com
    network: ws
    ws-opts:
      path: /vmess
      headers:
        Host: {z["add"]}
    udp: true


proxies:
  - name: {z["ps"]}
    server: {z["add"]}
    port: 80
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: false
    skip-cert-verify: true
    servername: bug.com
    network: ws
    ws-opts:
      path: /vmess
      headers:
        Host: {z["add"]}
    udp: true

proxies:
  - name: {z["ps"]}
    server: {z["add"]}`
    port: 443
    type: vmess
    uuid: {z["id"]}
    alterId: 0
    cipher: auto
    tls: true
    skip-cert-verify: true
    servername: bug.com
    network: grpc
    grpc-opts:
      grpc-service-name: vmess
    udp: true
"""
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ VMESS ACCOUNT ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{z["ps"]}`
**🔰 Domain:** `{z["add"]}`
**🔰 Port TLS:** `{z["port"]}`
**🔰 Port HTTP:** `{z1["port"]}`
**🔰 UUID:** `{z["id"]}`
**🔰 Alter ID:** `{z["aid"]}`
**🔰 Security:** `Auto`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 Path:** `{z["path"]}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TLS VMESS Url:**
`{x[0].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 HTTP VMESS Url:**
`{x[1].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 GRPC VMESS Url:**
`{x[2].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					elif len(list(x)) == 2:
						z = base64.b64decode(x[0].replace("vmess://","")).decode("ascii")
						z = json.loads(z)
						z1 = base64.b64decode(x[1].replace("vmess://","")).decode("ascii")
						z1 = json.loads(z1)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ VMESS ACCOUNT ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{z["ps"]}`
**🔰 Domain:** `{z["add"]}`
**🔰 Port TLS:** `{z["port"]}`
**🔰 Port HTTP:** `{z1["port"]}`
**🔰 UUID:** `{z["id"]}`
**🔰 Alter ID:** `{z["aid"]}`
**🔰 Security:** `Auto`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 Path:** `{z["path"]}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TLS VMESS Url:**
`{x[0].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 HTTP VMESS Url:**
`{x[1].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					with open('andi/clash_config.txt', 'a') as save:
						save.write(f"{msg1}")
					file = await bot.upload_file('andi/clash_config.txt')
					await bot.send_file(event.chat_id, file, force_document=True)  
					os.remove("andi/clash_config.txt")
					
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await vmesstrials_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await vmesstrials_(event)
				
@bot.on(events.NewMessage(pattern="(?:.trialtr|/trialtr) (.*)"))  
async def trojanwstrials(event):
		async def trojanwstrials_(event):
				data = event.pattern_match.group(1)
				domain = data.split(":")[0]
				param = f":6969/trial-trojan"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(0),sender.id,))
						count = db.execute("SELECT counted FROM trojanws WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojanws SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					x = r.text.replace('[','').replace(']','').replace('"',
'').split(',')
					print(x)
					if len(list(x)) == 2:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg1 = f"""
proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: ws
    ws-opts:
      path: /trojan
      headers:
        Host: {domain}
    udp: true

proxies:
  - name: {remarks}
    server: {domain}
    port: 443
    type: trojan
    password: {uuid}
    skip-cert-verify: true
    sni: bug.com
    network: grpc
    grpc-opts:
      grpc-service-name: trojan
    udp: true
"""
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ TRIAL Trojan-WS  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port TLS:** `443`
**🔰 UUID:** `{uuid}`
**🔰 Encryption:** `none`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 NetWork:** `GRPC/TLS`
**🔰 Path:** `{path}`
**🔰 ServiceName:** `trojan`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN WS WS Url:**
  `{x[0].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN GRPC  Url:**
  `{x[1].strip('"').replace(' ','')}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					elif len(list(x)) == 1:
						remarks = re.search("#(.*)",x[0]).group(1)
						domain = re.search("@(.*?):",x[0]).group(1)
						uuid = re.search("trojan://(.*?)@",x[0]).group(1)
						path = re.search("path=(.*?)&",x[0]).group(1)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** ▫️️☘ TRIAL Trojan-WS  ☘▫️**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Remarks:** `{remarks}`
**🔰 Domain:** `{domain}`
**🔰 Port TLS:** `443`
**🔰 UUID:** `{uuid}`
**🔰 Encryption:** `none`
**🔰 NetWork:** `Websocket` `(WS)`
**🔰 NetWork:** `TLS`
**🔰 Path:** `{path}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 TROJAN WS Url:**
  `{x[0].replace(" ","").strip()}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""

					await event.respond(msg)
					with open('andi/clash_config.txt', 'a') as save:
						save.write(f"{msg1}")
					file = await bot.upload_file('andi/clash_config.txt')
					await bot.send_file(event.chat_id, file, force_document=True)  
					os.remove("andi/clash_config.txt")
					
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trojanwstrials_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trojanwstrials_(event)
