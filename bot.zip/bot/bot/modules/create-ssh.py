from bot import *

@bot.on(events.CallbackQuery(data=b'renssh'))
async def renssh(event):
	async def renssh_(event):
		z = db.execute("SELECT buttonname FROM ssh").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga)
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Informasi Server ⚜**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Harga:** `{harga}`
**━━━━━━━━━━━━━━━━━━━**
** Pilih Ya Untuk Lanjut...!! **
**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")],
[Button.inline("60 Day","60")],
[Button.inline("90 Day","90")] ])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
				if exp == "30":
					min = harga
				if exp == "60":
					min = harga * 2
				if exp == "90":
					min = harga * 3
			if int(val["saldo"]) < min:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				param = f":6969/renssh?user={user}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						db.execute("UPDATE user SET created = ? WHERE member = ?",(int(val["created"])+int(1),sender.id,))
						db.commit()
					except Exception as e:
						print(str(e))
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**☘ Extend SSH Account ☘**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Host:** `{domain}`
**🔰 Username:** `{user.strip()}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 🗓 Extendted:** `{exp} Days`
**━━━━━━━━━━━━━━━━━━━**
"""
				
					await event.respond(msg)
					dat = {
				"email":val["email"],
                                "protocol":"Renewed SSH",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Not Found`, `Server Error`
""")
				
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await renssh_(event)
	else:
		await renssh_(event)
		
@bot.on(events.CallbackQuery(data=b'ssh-trial'))
async def trial(event):
		async def trial_(event):
			z = db.execute("SELECT buttonname FROM ssh").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				portwsntls = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				nsdomain = db.execute("SELECT ns FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				pubkey = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				link = db.execute("SELECT link FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				portwstls = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				portdb = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f"/trial-ssh"
				trial = requests.get("http://"+domain+":6969/trial-ssh").text.split(":")
				exp = 1
				today = DT.date.today()
				later = today + DT.timedelta(days=int(exp))
				print(trial)
				msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**☘ TRIAL SSH Account ☘**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Host:** `{domain}`
**🔰 Host DNS:** `{nsdomain}`
**🔰 Username:** `{trial[0].strip()}`
**🔰 Password:** `{trial[1]}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 OpenSSH:** `22`
**🔰 SSL/TLS:** `443`
**🔰 DropBear:** `{portdb}`
**🔰 WS SSL:** `{portwstls}`
**🔰 WS HTTP:** `{portwsntls}`
**🔰 Squid:** `3128` `(Limit To IP Server)`
**🔰 BadVPN UDPGW:** `7100` **-** `7300`
**🔰 PubKey:** `{pubkey}`
**━━━━━━━━━━━━━━━━━━━**
**☘ Payload WS HTTP ☘**
`GET / HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━**
**☘ Payload WSS HTTPS ☘**
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Link Config OVPN :** `http://{link}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 🗓Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
				await event.respond(msg)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def ssh(event):
	async def ssh_(event):
		z = db.execute("SELECT buttonname FROM ssh").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga = db.execute("SELECT harga FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		portwsntls = db.execute("SELECT portwsntls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		nsdomain = db.execute("SELECT ns FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		pubkey = db.execute("SELECT pubkey FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		link = db.execute("SELECT link FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		portwstls = db.execute("SELECT portwstls FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		portdb = db.execute("SELECT portdb FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		limitip = db.execute("SELECT limitip FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim); print(limitip)
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ Informasi Server ⚜**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Harga:** `{harga}`
**🔰 Total Akun Dibuat:** `{cont}/{lim}`
**━━━━━━━━━━━━━━━━━━━**
** Pilih Ya Untuk Lanjut...!! **
**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as pw:
					await event.respond("**Password: **")
					pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					pw = await pw
					pw = pw.message.message.replace(" ","")
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")],
[Button.inline("60 Day","60")],
[Button.inline("90 Day","90")] ])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
				if exp == "30":
					min = harga
				if exp == "60":
					min = harga * 2
				if exp == "90":
					min = harga * 3
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < min:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				param = f"/adduser/exp?user={user}&password={pw}&exp={exp}&limitip={limitip}"
				r = requests.get("http://"+domain+":6969"+param).text
				if r == "success":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						db.execute("UPDATE user SET created = ? WHERE member = ?",(int(val["created"])+int(1),sender.id,))
						count = db.execute("SELECT counted FROM ssh WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE ssh SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except Exception as e:
						print(str(e))
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**☘ SSH Account ☘**
**━━━━━━━━━━━━━━━━━━━**
**🔰 Host:** `{domain}`
**🔰 Host DNS:** `{nsdomain}`
**🔰 Username:** `{user.strip()}`
**🔰 Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 OpenSSH:** `22`
**🔰 SSL/TLS:** `443`
**🔰 DropBear:** `{portdb}`
**🔰 WS SSL:** `{portwstls}`
**🔰 WS HTTP:** `{portwsntls}`
**🔰 Squid:** `3128` `(Limit To IP Server)`
**🔰 BadVPN UDPGW:** `7100` **-** `7300`
**🔰 PubKey:** `{pubkey}`
**━━━━━━━━━━━━━━━━━━━**
**☘ Payload WS HTTP ☘**
`GET / HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━**
**☘ Payload WSS HTTPS ☘**
`GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━**
**🔰 Link Config OVPN :** `http://{link}`
**━━━━━━━━━━━━━━━━━━━**
**🔰 🗓Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
				
					await event.respond(msg)
					
					dat = {
				"email":val["email"],
                                "protocol":"SSH",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await ssh_(event)
	else:
		await ssh_(event)
		
@bot.on(events.CallbackQuery(data=b'ssh-menu'))
async def smenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namash()
	har = hargash()
	serv = []
	for x, y in zip(ser, har):
		print(x, y)
		y = "{:,}".format(y)
		serv.append(f"**🔰 {x}  ** `Rp. {y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ SSH Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[
[Button.inline("☘ Created ssh ☘","create-ssh"),
Button.inline("☘ Created Trial ssh ☘","ssh-trial")],
[Button.inline("☘ Renew ssh Account ☘","renssh")],
[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**⚜ SSH Account Menu ⚜**
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg, buttons=[
[Button.inline("☘ Created ssh ☘","create-ssh"),
Button.inline("☘ Created Trial ssh ☘","ssh-trial")],
[Button.inline("☘ Renew ssh Account ☘","renssh")],
[Button.inline("🔙 Back To Menu",f"menu")]])

