from markupsafe import Markup
import datetime
import asyncio, os
import hypercorn.asyncio
from flask import *
from asgiref.wsgi import WsgiToAsgi
from hypercorn.config import Config
from telethon import *
import sqlite3, hmac, hashlib
import requests
import datetime as xontol
import requests as req 
import os, requests, math, time, urllib3

apiKey = "30kOWkNcpU64hX7FX1a4KRWTq2AlqrzuXZtd1Ms5"
privateKey = "YCec8-fK6KU-4vkaI-gBxhd-1l33W"
merchant_ref = "ajunvpn"
merchant_code = "T22229" 
expiry = int(time.time() + (24*60*60)) # 24 jam
LOGS = -1001152031033
#LOGS = -1001749114499
HTTP_TIMEOUT = 60
app = Flask(__name__)
#app.secret_key = "XolPanel 2.0"
aapp = WsgiToAsgi(app)
config = Config()
config.bind = ["0.0.0.0:5196"]
#BRAND = "XolPanel"

class TimeoutRequestsSession(requests.Session):
    def request(self, *args, **kwargs):
        kwargs.setdefault('timeout', HTTP_TIMEOUT)
        return super(TimeoutRequestsSession, self).request(*args, **kwargs)

requests = TimeoutRequestsSession()
requests.headers.update({"AUTH_KEY":"meki"})
import datetime as DT
import sqlite3, base64,json, re
#token = "5087102188:AAElDqIPfooJUk6BN4pW_PYdPPmomtZUCTs"
token = "7013710027:AAHbgRq0MVyf921lI3mbtoaDI8B2Fv7d0Oo"
bot = TelegramClient("bxxxi9hhyhwhwiiggshdhsh69YQYyt","15995433","6fc6fd0c77e5494c14724442abe46e5e").start(bot_token=token)
#os.system("clear")


try:
	open("bot/biji.db")
except:
	x = sqlite3.connect("bot/biji.db")
	sc = f"""
CREATE TABLE user (
		saldo INTEGER NOT NULL DEFAULT 0,
		member INTEGER,
		email TEXT,
		created TEXT,
		counted INTEGER DEFAULT 0
		);
"""
	sc1 = f"""
CREATE TABLE vmess (
		harga INTEGER,
		quota INTEGER,
		limitip INTEGER,
		buttonname TEXT,
		domain INTEGER,
		counted INTEGER DEFAULT 0,
		limcounted INTEGER
		);
"""
	sc2 = f"""
CREATE TABLE trojan (
		harga INTEGER,
		quota INTEGER,
		limitip INTEGER,
		buttonname TEXT,
		domain INTEGER,
		counted INTEGER DEFAULT 0,
		limcounted INTEGER
		);
"""
	sc4 = f"""
CREATE TABLE trojanws (
		harga INTEGER,
		quota INTEGER,
		limitip INTEGER,
		buttonname TEXT,
		domain INTEGER,
		counted INTEGER DEFAULT 0,
		limcounted INTEGER
		);
"""
	sc3 = f"""
CREATE TABLE trojango (
		harga INTEGER,
		buttonname TEXT,
		domain INTEGER,
		counted INTEGER DEFAULT 0,
		limcounted INTEGER
		);
"""
	sc5 = f"""
CREATE TABLE trojangfw (
		harga INTEGER,
		buttonname TEXT,
		domain INTEGER,
		counted INTEGER DEFAULT 0,
		limcounted INTEGER
		);
"""
	sc6 = f"""
CREATE TABLE ssh (
		harga INTEGER,
		limitip INTEGER,
		portdb TEXT,
		portwstls TEXT,
		portwsntls TEXT,
		link TEXT,
		buttonname TEXT,
		pubkey TEXT,
		ns TEXT,
		domain INTEGER,
		counted INTEGER DEFAULT 0,
		limcounted INTEGER
		);
"""
	sc7 = f"""
CREATE TABLE tripay (
		sign TEXT
		);
"""
	
	x.executescript(sc)
	x.executescript(sc1)
	x.executescript(sc2)
	x.executescript(sc3)
	x.executescript(sc4)
	x.executescript(sc5)
	x.executescript(sc6)
	x.executescript(sc7)
	c = x.cursor() 
	c.execute("CREATE TABLE admin (user_id INTEGER NOT NULL);") 
	c.execute("INSERT INTO admin (user_id) VALUES (?)",("5723591082",))
	c.execute("INSERT INTO admin (user_id) VALUES (?)",("5723591082",))
	
	x.commit()

async def sbot():
	await bot.start(bot_token=token)
	print("client started")
	await hypercorn.asyncio.serve(aapp, config)
	
def cs(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])


def members():
	member = get_db().execute("SELECT member FROM user").fetchall()
	#print(member)
	member = len([x[0] for x in member])
	return member

for x in ["/start","/hello"]:
	@bot.on(events.NewMessage(pattern=x))
	async def hello(event):
		x = await event.get_sender()
		msg = f"""
**━━━━━━━━━━━━━━━━**
**» Name:** `{x.first_name}`
**» Username:** `@{x.username}`
**» User ID:** `{x.id}`
**━━━━━━━━━━━━━━━━**
**» Menu:** [ /menu ]
**» 🤖XolPanel**
**» 👤Member: **`{members()}`
**━━━━━━━━━━━━━━━━**
"""
		await event.respond(msg)
		
def get_db():
	x = sqlite3.connect("bot/biji.db")
	x.row_factory = sqlite3.Row
	return x

def minus(member,saldo,val):
	db = get_db()
	db.execute("UPDATE user SET saldo = ? WHERE member = ?",
	(int(val["saldo"])-int(saldo),member,))
	db.commit()
uptime = "Unknown"

def createds():
	xx = get_db().execute("SELECT created FROM user").fetchall()
	#print(xx)
	xx = ([x[0] for x in xx])
	if xx:
		#print(xx)
		return xx
		
		
def emailuser():
	xx = get_db().execute("SELECT email FROM user").fetchall()
	#print(xx)
	xx = ([x[0] for x in xx])
	if xx:
		#print(xx)
		return xx

def saldouser():
	xx1 = get_db().execute("SELECT saldo FROM user").fetchall()
	#print(xx1
	xx1 = ([x[0] for x in xx1])
	if xx1:
		#print(xx1)
		return xx1

def domains():
	domain = get_db().execute("SELECT domain FROM vmess").fetchall()
	print(domain)
	domain = len([x[0] for x in domain])
	return domain
	
def domainstr():
	domain = get_db().execute("SELECT domain FROM trojanws").fetchall()
	print(domain)
	domain = len([x[0] for x in domain])
	return domain
	
def namas():
	xx = get_db().execute("SELECT buttonname FROM vmess").fetchall()
	print(xx)
	xx = ([x[0] for x in xx])
	if xx:
		print(xx)
		return xx
		
def hargas():
	xx1 = get_db().execute("SELECT harga FROM vmess").fetchall()
	print(xx1)
	xx1 = ([x[0] for x in xx1])
	if xx1:
		print(xx1)
		return xx1
		
def namash():
	xx = get_db().execute("SELECT buttonname FROM ssh").fetchall()
	print(xx)
	xx = ([x[0] for x in xx])
	if xx:
		print(xx)
		return xx
		
def hargash():
	xx1 = get_db().execute("SELECT harga FROM ssh").fetchall()
	print(xx1)
	xx1 = ([x[0] for x in xx1])
	if xx1:
		print(xx1)
		return xx1
		
def namastrws():
	xx = get_db().execute("SELECT buttonname FROM trojanws").fetchall()
	print(xx)
	xx = ([x[0] for x in xx])
	if xx:
		print(xx)
		return xx
		
def hargastrws():
	xx1 = get_db().execute("SELECT harga FROM trojanws").fetchall()
	print(xx1)
	xx1 = ([x[0] for x in xx1])
	if xx1:
		print(xx1)
		return xx1
		
def namasgfw():
	xx = get_db().execute("SELECT buttonname FROM trojangfw").fetchall()
	print(xx)
	xx = ([x[0] for x in xx])
	if xx:
		print(xx)
		return xx
		
def hargasgo():
	xx1 = get_db().execute("SELECT harga FROM trojango").fetchall()
	print(xx1)
	xx1 = ([x[0] for x in xx1])
	if xx1:
		print(xx1)
		return xx1
		
def namasgo():
	xx = get_db().execute("SELECT buttonname FROM trojango").fetchall()
	print(xx)
	xx = ([x[0] for x in xx])
	if xx:
		print(xx)
		return xx
		
def hargasgfw():
	xx1 = get_db().execute("SELECT harga FROM trojangfw").fetchall()
	print(xx1)
	xx1 = ([x[0] for x in xx1])
	if xx1:
		print(xx1)
		return xx1
		
def valid(id):
	db = get_db()
	x = db.execute("SELECT saldo, member, email, created FROM user WHERE member = (?)",(id,)).fetchone()
	if not x:
		return "false"
	else:
		return {"saldo":x[0],"member":x[1],"email":x[2],"created":x[3]}
@bot.on(events.NewMessage(pattern="^.ping")) 
async def _(event):
	if event:
		start = time.time()
		message = await event.respond("**Pong!**")
		delta = time.time() - start
		await message.edit(f"**Pong!** `{delta:.3f}` seconds")
		

@bot.on(events.NewMessage(pattern=r"(?:.punten|punten)$"))
async def free(event):
	async def free_(event):
		email = str(sender.username)+"@xolpanel.net"
		db.execute("INSERT INTO user (saldo,member,email,created) VALUES (?,?,?,?)",
		("0",sender.id,email,"0",))
		db.commit()
		await event.reply(f"""
**━━━━━━━━━━━━━━━━**
**Sukses Terdaftar!**
**━━━━━━━━━━━━━━━━**
**» Name:** `{sender.first_name}`
**» Username:** @{sender.username}
**» User ID:** `{sender.id}`
**━━━━━━━━━━━━━━━━**
**» Menu:** [ /menu ]
**» 🤖  XolPanel**
**» 💬  XolPanelDC**
**━━━━━━━━━━━━━━━━**
""")
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	if sender.id not in a and val == "false":
		await free_(event)
	else:
		await event.reply("**Anda Sudah Terdaftar!**")

@bot.on(events.NewMessage(pattern="^.resetbul")) 
async def reset(event):
	db = get_db()
#	db.execute("DELETE FROM user WHERE created")
	created = db.execute("SELECT created FROM user").fetchone()[0]
	db.execute("UPDATE user SET created = (?)",("0",))
	db.commit()
	await event.respond("**Berhasil mereset income bulanan**")


@bot.on(events.CallbackQuery(data=b'list'))
@bot.on(events.NewMessage(pattern="(?: /list|.list)$"))
async def enu(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	email = emailuser()
	saldo = saldouser()
	created = createds()
	bol = []
	for u, i, e in zip (email, saldo, created):
		print(u, i)
		bol.append(f"🔰 {u}   | Rp.{i}  |  {e}   \n")
	if sender.id in a:
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
         ⚜ Total List Member ⚜
━━━━━━━━━━━━━━━━━━━━━━━
    -- EMAIL -- SALDO -- CREATED -- 
━━━━━━━━━━━━━━━━━━━━━━━
{"".join(bol)}

━━━━━━━━━━━━━━━━━━━━━━━
"""
		with open('bot/list_member.txt', 'a') as save:
			save.write(f"{msg}")
		file = await bot.upload_file('bot/list_member.txt')
		await bot.send_file(event.chat_id, file, force_document=True)  
		os.remove("bot/list_member.txt")


async def notifs(data,event):
	db = get_db()
#	valdi = db.exexute("SELECT bool FROM notif").fetchone()[0]
#	if valdi == "true":
	count = db.execute("SELECT counted FROM user").fetchone()[0]
	db.execute("UPDATE user SET counted = (?)",(int(count)+1,))
	db.commit()
	print(data)
#	data = json.loads(data)
	msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨⚡️ New Transactions ⚡️⟩**
**━━━━━━━━━━━━━━━━**
**» Transactions Count:** `{count}`
**» Email Reseller:** `{data["email"]}`
**» Server:** `{data["server"]}`
**» Protocol:** `{data["protocol"]}`
**» Expiry:** `{data["exp"]}`
**━━━━━━━━━━━━━━━━**
"""
	await event.client.send_message(LOGS,msg)

async def TripayNotif(email,saldo):
	db = get_db()
	today = DT.date.today()
	date = "{:%B %d, %Y}".format(xontol.datetime.strptime(str(today),"%Y-%m-%d"))
	sign = db.execute("SELECT * FROM tripay").fetchall()
	msg = f"""
**━━━━━━━━━━━━━━━━**
**New TopUp [Instant] | TriPay**
**━━━━━━━━━━━━━━━━**
**» TopUp counts:** `{str(len(sign))}`
**» Date:** `{date}`
**» Email:** `{email}`
**» Balance:** `{saldo}`
**━━━━━━━━━━━━━━━━**
"""
	return await bot.send_message(LOGS,msg)
	
async def notifstrr(data,event):
	db = get_db()
#	valdi = db.exexute("SELECT bool FROM notif").fetchone()[0]
#	if valdi == "true":
	count = db.execute("SELECT counted FROM user").fetchone()[0]
	db.execute("UPDATE user SET counted = (?)",(int(count)+1,))
	db.commit()
	print(data)
#	data = json.loads(data)
	msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨⚡️ New Trial Transactions ⚡️⟩**
**━━━━━━━━━━━━━━━━**
**» Transactions Count:** `{count}`
**» Email Reseller:** `{data["email"]}`
**» Server:** `{data["server"]}`
**» Protocol:** `{data["protocol"]}`
**» Expiry:** `{data["exp"]}`
**━━━━━━━━━━━━━━━━**
"""
	await event.client.send_message(LOGS,msg)
	

@bot.on(events.NewMessage(pattern="(?:.bcast|/bcast)"))
async def bcast(event):
	db = get_db()
	memberz = [x[0] for x in db.execute("SELECT member FROM user").fetchall()]
	async def bcast_(event):
		if event.is_reply:
			msg = await event.get_reply_message()
			for res in memberz:
				await event.client.send_message(res,msg)
			await event.respond(f"**Berhasil Broadcast ke** `{str(len(memberz))}` **Reseller**")
		else:
			await event.respond("**Reply To Message, File, Media, Images, Or Sticker!**")
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await bcast_(event)
	else:
		await event.respond("**Akses Ditolak**")


@bot.on(events.NewMessage(pattern="(?:.res|/res)"))
async def restassrt(event):
	db = get_db()
	sender = await event.get_sender()
	if sender.id:
		async with bot.conversation(event.chat_id) as dom:
			await event.respond("**DOMAIN: **")
			dom = dom.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			dom = await dom
			dom = dom.message.message
			z = requests.get(f"http://ip-api.com/json/{dom}?fields=status").json()
			m  = f"""{z["status"]}"""
			if m == "success":
				u = requests.get("http://"+dom+":6969/restart").text
				await event.respond("**Restarting Service Done**")
			else:
				await event.respond("**Restarting Service Failed**")
    
@app.context_processor
def inject_stage_and_region():
    return dict(brand=BRAND)

servers = get_db().execute("SELECT domain FROM vmess").fetchall()
#servers = [
#	    {"host":"0",
#	     "name":"Dummy Server",
#	     "price":"10"}]


async def OTPSendBot(telegram, otp):
	today = DT.date.today()
	date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
	msg = f"""
**━━━━━━━━━━━━━━━━**
**OTP From XolPanel**
**━━━━━━━━━━━━━━━━**
**» Code:** `{otp}`
**» Date:** `{date}`
**━━━━━━━━━━━━━━━━**
"""
	return await bot.send_message(int(telegram),msg)


async def Notif(namaakun,protocol,exp,email,price,isp):
	db = get_db()
	today = DT.date.today()
	date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
#	trans = db.execute("SELECT * FROM transaksi").fetchall()
	count = db.execute("SELECT counted FROM user").fetchone()[0]
	db.execute("UPDATE user SET counted = (?)",(int(count)+1,))
	db.commit()
	price = "{:,}".format(price)
	msg = f"""
**━━━━━━━━━━━━━━━━**
**New transactions**
**━━━━━━━━━━━━━━━━**
**» Transaction counts:** `{int(count)+1}`
**» Date:** `{date}`
**» Email:** `{email}`
**━━━━━━━━━━━━━━━━**
**» Protocol:** `{protocol}` **|** `{isp}`
**» Account Name:** `{namaakun}`
**» Expiry:** `{exp}`
**» Price:** `Rp. {price}`
**━━━━━━━━━━━━━━━━**
"""
	return await bot.send_message(LOGS,msg)

async def TripayNotif(email,saldo):
	today = DT.date.today()
	db = get_db()
	date = "{:%B %d, %Y}".format(datetime.datetime.strptime(str(today),"%Y-%m-%d"))
	sign = db.execute("SELECT * FROM tripay").fetchall()
	msg = f"""
**━━━━━━━━━━━━━━━━**
**New TopUp [Instant]**
**━━━━━━━━━━━━━━━━**
**» TopUp counts:** `{str(len(sign))}`
**» Date:** `{date}`
**» Email:** `{email}`
**» Balance:** `{saldo}`
**━━━━━━━━━━━━━━━━**
"""
	return await bot.send_message(LOGS,msg)
